final public class ChessMove {
    public int from;
    public int to;
}
