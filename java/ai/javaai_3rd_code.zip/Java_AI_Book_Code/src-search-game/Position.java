abstract public class Position {
}