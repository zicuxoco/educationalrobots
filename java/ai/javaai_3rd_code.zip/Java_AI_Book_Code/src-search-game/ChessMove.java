public class ChessMove extends Move {
    public int from;
    public int to;
}
