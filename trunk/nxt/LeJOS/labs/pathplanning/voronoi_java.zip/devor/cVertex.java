class cVertex {
    
  cVertex prev, next;
  cPointi v;
  boolean ear = false;
  int vnum;
  cEdge duplicate;
  boolean  onhull;		
  boolean  mark;

  cVertex() {
    prev = next = null;
    v = new cPointi();
    vnum = 0;
    duplicate = null;
    onhull = false;
    mark = false;
  }

  cVertex(int i, int j) {	
    v = new cPointi();
    v.x = i;
    v.y = j;
    v.z = i * i + j*  j;
    prev = next = null;
  }

  cVertex(int x, int y, int z) {
    v = new cPointi();
    v.x = x;
    v.y = y;
    v.z = z;
    prev = next = null;
  }

  public void ResetVertex3D()
  {
    v.z = v.x * v.x + v.y * v.y;
  }
  
} 









