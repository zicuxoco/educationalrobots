class cFaceList {
	int n;

	cFace head;

	cFaceList() {
		head = null;
		n = 0;
	}

	public void InitHead(cFace h) {
		head = new cFace();
		head = h;
		head.next = head.prev = head;
		n = 1;
	}

	public void InsertBefore(cFace newF, cFace oldF) {
		if (head == null)
			InitHead(newF);
		else {
			oldF.prev.next = newF;
			newF.prev = oldF.prev;
			newF.next = oldF;
			oldF.prev = newF;
			n++;
		}
	}
	
	public void InsertBeforeHead(cFace e) {
		if (head == null)
			InitHead(e);
		else {
			InsertBefore(e, head);
		}
	}

	public cFace MakeNullFace() {
		cFace f = new cFace();
		InsertBeforeHead(f);
		return f;
	}

	public void Delete(cFace e) {

		if (head == head.next)
			head = null;
		else if (e == head)
			head = head.next;

		e.prev.next = e.next;
		e.next.prev = e.prev;
		n--;
	}

	public void ClearFaceList() {
		if (head != null)
			head = null;
		n = 0;
	}
}
