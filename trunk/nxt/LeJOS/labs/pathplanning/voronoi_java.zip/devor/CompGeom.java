import java.applet.*;
import java.awt.*;

public class CompGeom extends Applet {
	private static final long serialVersionUID = 1L;

	private Button start;

	private CompGeomTest test;

	private int w, h;

	public void init() {
		start = new Button("Voronoi/Delaunay Applet...");
		w = 900;
		h = 550;
		setLayout(new FlowLayout(FlowLayout.CENTER));
		setBackground(Color.lightGray);
		add(start);
	}

	public boolean action(Event e, Object o) {
		if (e.target == start) {
			test = new CompGeomTest(this);
			test.setSize(w, h);
			test.setResizable(false);
			test.setVisible(true);
		}
		return true;
	}
}
