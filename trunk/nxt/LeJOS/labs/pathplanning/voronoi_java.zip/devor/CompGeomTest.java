import java.awt.*;
import java.applet.*;

public class CompGeomTest extends Frame {
	private static final long serialVersionUID = 1L;

	private Button clear, close, simde, simvo;
	private Checkbox hull, deltri, voronoi;
    
	private Panel subp1, subp022, subp2, subp3,  p,canvasp;
	private GeomCanvas c;
	
	private int cw, ch; // width and height for info frame and canvas

	private Font f;

	public CompGeomTest(Applet a) {
		super("COSC 6114 Computational Geometry - Zhenyu Pan");
		setBackground(Color.lightGray);

		// cw = Integer.parseInt(a.getParameter("canvas width"));
		cw = 750;
		// ch = Integer.parseInt(a.getParameter("canvas height"));
		ch = 550;

		clear = new Button("Clear Screen");
		close = new Button("Close Window");
		simde = new Button("Simulation Delaunay");
		simvo = new Button("Simulation Voronoi");
		hull = new Checkbox("Show Convex Hull");
		deltri = new Checkbox("Show Delaunay");
		voronoi = new Checkbox("Show Voronoi");

		subp1 = new Panel();
		subp1.setLayout(new BorderLayout());
		subp1.add("Center",clear);
		subp1.add("South",close);

		subp022 = new Panel();
		subp022.setLayout(new BorderLayout());
		subp022.add("Center",simde);
		subp022.add("South",simvo);

		subp3 = new Panel();
		subp3.setLayout(new BorderLayout());
		subp3.add("North",hull);
		subp3.add("Center",deltri);
		subp3.add("South",voronoi);

		subp2 = new Panel();
		subp2.setLayout(new BorderLayout());
		subp2.add("North", subp1);
		subp2.add("Center", subp022);
		subp2.add("South", subp3);

		p = new Panel();
		p.setBackground(Color.lightGray);
		p.setLayout(new BorderLayout());
		p.add("North", subp2);

		c = new GeomCanvas(cw, ch, this);
		c.SetRegime("point");

		canvasp = new Panel();
		canvasp.setLayout(new BorderLayout());
		canvasp.add("Center", c);

		setLayout(new BorderLayout());
		add("Center", canvasp);
		add("East", p);

	}

	public boolean action(Event e, Object o) {
		if (e.target instanceof Checkbox) {
			Checkbox checkbox = (Checkbox) e.target;
			if (e.target == hull)
				c.ToCH(checkbox.getState());

			if (e.target == deltri) {
				c.ToDelTri(checkbox.getState());
			}
			if (e.target == voronoi){
				c.ToVoronoi(checkbox.getState());
			}
		} // end of instanceof Checkbox

		if (e.target instanceof Button) {
			if (e.target == clear) {
				c.ToBeCleared();// boolean variable
				c.CoorClear();
				c.SetPaint();
			}
			if (e.target == close) {
				setVisible(false);
				c.CoorClear();
    			c.animator=null;
			}
			if (e.target == simde) {
				c.SimDe();// boolean variabble
			}

			if (e.target == simvo) {
				c.SimVo();
			}
		}
		return true;
	}

	public void processevent(AWTEvent e) {
		if (e.getID() == Event.WINDOW_DESTROY) {
			setVisible(false);
			dispose();
			return;
		}
		super.processEvent(e);
	}

	public void resetBLabel(Button bprev) {
		bprev.setFont(f);
	}

}
