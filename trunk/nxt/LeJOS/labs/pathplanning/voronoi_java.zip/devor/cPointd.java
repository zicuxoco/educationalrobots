class cPointd {
	double x;

	double y;

	cPointd() {
		x = y = 0;
	}

	cPointd(int x, int y) {
		this.x = x;
		this.y = y;
	}
}
