import java.awt.*;
import java.awt.event.*;

public class GeomCanvas extends Canvas implements Runnable {

	private static final long serialVersionUID = 1L;

	static final int VSIZE = 6;

	private cVertexList list;

	private DelaunayTri delTri;

	private ConvexHull2D myCH;

	private voronoi myVor;

	private boolean toClear, simde, simvo, toPaint, toDelTri, toCH, toVoronoi;

	private cVertex movingV;

	private Graphics gContext; // variables for double buffering

	private Image buffer;

	private int CanW, CanH; // width and height of the drawing canvas

	private int w = VSIZE, h = VSIZE; // w. and h. of vertices

	Thread animator;

	GeomCanvas(int cw, int ch, CompGeomTest frame) {
		setSize(cw, ch);
		CanW = cw;
		CanH = ch;
		setBackground(Color.lightGray);
		toClear = simde = simvo = false;
		toPaint = toDelTri = toCH = false;
		list = new cVertexList();
		myCH = new ConvexHull2D(list);
		delTri = new DelaunayTri(list);
		myVor = new voronoi();
		enableEvents(AWTEvent.MOUSE_EVENT_MASK);
		enableEvents(AWTEvent.MOUSE_MOTION_EVENT_MASK);
		start();
	}

	public void SetRegime(String state) {
	}

	public void ToBeCleared() {
		toClear = true;
		repaint();
	}

	public void ToDelTri(boolean iftrue) {
		toPaint = true;
		toDelTri = iftrue;
		repaint();
	}

	public void ToVoronoi(boolean iftrue) {
		toPaint = true;
		toVoronoi = iftrue;
		repaint();
	}

	public void ToCH(boolean iftrue) {
		toPaint = true;
		toCH = iftrue;
		repaint();
	}

	public void CoorClear() {
		list.ClearVertexList();
		myCH.ClearHull();
		delTri.ClearDelaunay();
		simde = false;
		simvo = false;
		toPaint = false;
		repaint();
	}

	public void SimDe() {
		simde = true;
		toPaint = true;
		repaint();
	}

	public void SimVo() {
		simvo = true;
		toPaint = true;
		repaint();
	}

	public int GetCount() {
		return list.n;
	}

	public void paint(Graphics g) {
		if (toClear) {
			g.setColor(Color.lightGray);
			g.fillRect(0, 0, CanW, CanH);
			CoorClear();
			toClear = false;
		}

		if (toPaint) {
			if (list == null)
				return;
			if (list.head == null)
				return;
			if (simde) {
				g.drawImage(buffer, 0, 0, this);
				return;
			}
			if(simvo){
				g.drawImage(buffer, 0, 0, this);
				return;
			}
			buffer = createImage(CanW, CanH);
			gContext = buffer.getGraphics();

			if (toDelTri) {
				delTri.Start(list);
				if (delTri.toDraw) {
					gContext.setColor(Color.blue);
					delTri.DrawDelaunayTri(gContext, w, h);
				}
			}
			if (toVoronoi) {
				myVor = new voronoi();
				gContext.setColor(Color.red);
				myVor.Sort(list);
				myVor.DrawVor(gContext);
			}
			if (toCH) {
				myCH = new ConvexHull2D(list);
				myCH.RunHull();
				gContext.setColor(Color.green);
				myCH.DrawHull(gContext, w, h);
			} 
			list.DrawPoints(gContext, w, h);

			g.drawImage(buffer, 0, 0, this);
			myCH.ClearHull();
			delTri.ClearDelaunay();
			myVor.dVoronoiDiagramGenerator();
			toPaint = false;

		}
	}

	public void update(Graphics g) {
		paint(g);
	}

	public void SetPaint() // needed for the applet
	{
		repaint();
	}

	public void processMouseMotionEvent(MouseEvent e) {
		int xset = 0, yset = 0;
		cVertexList listCur = list;
		if (e.getID() != MouseEvent.MOUSE_DRAGGED)
			return;
		xset = e.getX();
		yset = e.getY();
		if (movingV == null) {
			movingV = listCur.FindVertex(xset, yset, w, h);
			if (movingV == null) {
				System.out.println("There is no vertex to be moved");
				return;
			}
		}
		listCur.ResetVertex(movingV, xset, yset);
		toPaint = true;
		repaint();

	}

	public void processMouseEvent(MouseEvent e) {
		int xset = 0, yset = 0;
		cVertex vNear = new cVertex();
		cVertexList listCur = list;

		if (e.getID() != MouseEvent.MOUSE_CLICKED
				&& e.getID() != MouseEvent.MOUSE_RELEASED)
			return;
		if (e.getID() == MouseEvent.MOUSE_RELEASED)
			movingV = null;

		xset = e.getX();
		yset = e.getY();
		if (e.getID() == MouseEvent.MOUSE_CLICKED
				&& e.getButton() == MouseEvent.BUTTON1) {
			listCur.SetVertex(xset, yset);
			toPaint = true;
			// list.PrintVertices();
			repaint();
		}
		if (e.getID() == MouseEvent.MOUSE_CLICKED
				&& e.getButton() == MouseEvent.BUTTON3) {
			vNear = listCur.GetNearVertex(xset, yset);
			if (vNear != null) {
				listCur.Delete(vNear);
				if (listCur.n == 0) {
					toClear = true;
					CoorClear();
				}
			} else
				System.out.println("No vertex can be deleted.");
			toPaint = true;
			repaint();
		}
	}

	public void run() {
		while (Thread.currentThread() == animator) {
			if (simde) {
				gContext.setColor(Color.lightGray);
				gContext.fillRect(0, 0, CanW, CanH);
				list.DrawPoints(gContext, w, h);
				delTri.DeSim(true, gContext, w, h,this);
				toPaint = true;
				delTri.Start(list);
				delTri.DeSim(false, null, 0, 0,null);
				if (delTri.toDraw) {
					gContext.setColor(Color.blue);
					delTri.DrawDelaunayTri(gContext, w, h);
					delTri.DrawCircle(gContext, w, h);
					toPaint = true;
					list.DrawPoints(gContext, w, h);
					repaint();
					try {
						Thread.sleep(1200);
					} 
					catch (InterruptedException e) {
						break;
					}
				}
				simde = false;
				buffer = createImage(CanW, CanH);
				gContext = buffer.getGraphics();
				delTri.ClearDelaunay();
				toPaint = false;
			} 
			else if (simvo) {
				gContext.setColor(Color.lightGray);
				gContext.fillRect(0, 0, CanW, CanH);
				list.DrawPoints(gContext, w, h);
				myVor = new voronoi();
				myVor.VorSim(true, gContext, w, h,this);
				myVor.Sort(list);
				gContext.setColor(Color.red);
				myVor.DrawVor(gContext);
				list.DrawPoints(gContext, w, h);
				toPaint = true;
				repaint();
				try {

					Thread.sleep(1200);
				} catch (InterruptedException e) {
					break;
				}
				simvo = false;
				buffer = createImage(CanW, CanH);
				gContext = buffer.getGraphics();
				toPaint = false;
			}
			try {

				Thread.sleep(100);
			} catch (InterruptedException e) {
				break;
			}

		}
	}

	public void start() {
		animator = new Thread(this);
		animator.start();
	}

	public void stop() {
		animator = null;
		CoorClear();	
	}
}