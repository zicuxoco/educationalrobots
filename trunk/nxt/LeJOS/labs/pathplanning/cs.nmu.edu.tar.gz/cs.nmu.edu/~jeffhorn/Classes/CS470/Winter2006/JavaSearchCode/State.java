

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------
//
//    STATE:  write a class that implements this interface, stick in the
//            "planner.java" file, and you are done!!!  hahahahahaha
//
//    VERSION for A* search, modified 3-3-2006  for NMU's CS 470 AI course
//
//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

import java.awt.*;
import java.util.*;


interface State
  {

    //  Essential methods:

    public State get_initial();
    public State get_goal();
    public State get_copy() throws Exception;
    public boolean equals(State s);
    public void apply(Object operator) throws Exception;
    public boolean legal_state();
    public Stack possible_operators();
    public void paint(Graphics g);

    //  Nice-to-have's:

//    public boolean valid_goal(State init, State goal);
//    public void graph_plan(Plan solution);


  }