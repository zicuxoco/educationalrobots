
import java.io.*; 
import java.awt.*; 
import java.util.*; 



class Queue extends Stack
{


  //  main tests our queue class
  public static void main (String [] args) throws Exception  
    {
     Queue  q = new Queue();
     Integer x = new Integer(5);
     q.pushQ(x);
     x = new Integer(6);
     q.pushQ(x);
     x = new Integer(7);
     q.pushQ(x);
     System.out.println("\n" +q.popQ()+ "\n");
     System.out.println("\n" +q.popQ()+ "\n");
     System.out.println("\n" +q.popQ()+ "\n");
     }

   // this is the essential difference:  push into array[0]

   public void pushQ(Object obj)
          { 
//              push(obj);
                insertElementAt(obj,0); 
           }

   //  pop stays the same

   public Object popQ()
          {  return pop(); }

}
 
 


