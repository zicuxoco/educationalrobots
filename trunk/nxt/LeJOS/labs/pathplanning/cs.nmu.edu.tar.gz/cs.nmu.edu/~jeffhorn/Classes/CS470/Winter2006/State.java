
//-------------------------------------------------------------------------
//-------------------------------------------------------------------------
//
//    STATE:  write a class that implements this interface, stick in the
//            "planner.java" file, and you are done!!!  hahahahahaha
//
//    VERSION for A* search, modified 3-3-2006  for NMU's CS 470 AI course
//
//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

import java.awt.*;
import java.util.*;

interface State
  {

    public State get_initial();
    public State get_goal();
    public Stack get_goals();  //  Only if problem has multiple goal states
    public State get_copy() throws Exception;     //  Deep copy
    public boolean equals(State s);
    public void apply(Object operator) throws Exception;  //  State modifies itself
    public boolean legal_state();
    public Stack possible_operators();
    public void paint(Graphics g); //  Only if we want visualization

   // BEGINNING OF A* METHODS  (that is, methods needed by A* algorithm)
     //  Methods for tracing back along a plan (path through state space)
       public State previousState();  // Returns previous state in plan
       public Object previousOperator();  // Returns operator that changes
                                          // previous state to this state.
     // Hueristic (h) and Cost(g) functions for this state s:  f(s) = g(s) + h(s)
       public double g();   //  Current lowest known cost of traversing state space
                            //    from start state to this state
	   public double h();   //  Estimated cost of traversing state space
                            //    from this state to "nearest" goal state
       public double f();   //  f() should just return g() + h()

     // If implemented and used, these five methods could save on lookup times
       public boolean on_closed_listQ();  //  Returns true iff this state is on closed list
       public boolean on_open_listQ();   //  Returns true iff this state is on open list
       public void on_closed_list(boolean yes_no);  //  Tells this state whether
                                                    //  it is now on closed list
       public void on_open_list(boolean yes_no);  //  Tells this state whether
	                                              //  it is now on closed list
       public int hash_value();   //  Useful if hash table used to store states...
  }



