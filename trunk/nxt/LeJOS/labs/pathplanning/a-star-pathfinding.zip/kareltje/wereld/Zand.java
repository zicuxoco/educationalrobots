/*
 * Zand.java
 *
 * Created on 24 januari 2005, 17:08 door Bo Pennings
 */

package wereld;

import java.awt.*;

/**
 * zand op een vakje in de Wereld
 */
public class Zand extends WereldObject
{

    /**
     * Maak zand op het opgegeven vakje
     * 
     * @param x
     *                de horizontale index van het vakje (vanaf links, telt vanaf 0)
     * @param y
     *                de verticale index van het vakje (vanaf boven, telt vanaf 0)
     */
    public Zand(int x, int y)
    {
        super(x, y);
        int randomkleurverschil = ((int) (Math.random() * 17.0));
        setVulkleur(215 + randomkleurverschil, 205 + randomkleurverschil, 170 + randomkleurverschil);
    }

    /**
     * Teken het zand op het scherm
     */
    public void teken(Graphics g, int x, int y)
    {
        g.setColor(vulkleur);
        g.fillRect(x, y, Wereld.VAKGROOTTE, Wereld.VAKGROOTTE);
        g.setColor(lijnkleur);
        g.drawRect(x, y, Wereld.VAKGROOTTE, Wereld.VAKGROOTTE);
    }

}

