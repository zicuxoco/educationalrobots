package wereld;

import javax.swing.*;

/**
 * Write a description of class WriterToLog here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class WriterToLog implements Runnable
{
    // instance variables - replace the example below with your own
    private String line;
    private JTextArea textarea;
    private JScrollBar scrollbar;
    

    public WriterToLog(String l, JTextArea t, JScrollBar s)
    {
        line = l;
        textarea = t;
        scrollbar = s;
    }

    public void run() {
        
        textarea.append("\n" + line);
        scrollbar.setValue(scrollbar.getMaximum());
        
    }

}
