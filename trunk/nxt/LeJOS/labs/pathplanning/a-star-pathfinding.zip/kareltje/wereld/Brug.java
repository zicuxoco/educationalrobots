/*
 * Brug.java
 *
 * Created on 24 januari 2005, 17:08 door Bo Pennings
 */

package wereld;

import java.awt.*;

/**
 * Een brug op een vakje in de Wereld
 */
public class Brug extends WereldObject
{

    /**
     * Maak een brug op het opgegeven vakje
     * 
     * @param x
     *                de horizontale index van het vakje (vanaf links, telt vanaf 0)
     * @param y
     *                de verticale index van het vakje (vanaf boven, telt vanaf 0)
     */
    public Brug(int x, int y)
    {
        super(x, y);
        int randomkleurverschil = ((int) (Math.random() * 17.0));
        setVulkleur(128 + randomkleurverschil, 64 + randomkleurverschil, 0);
    }

    /**
     * Teken de brug op het scherm
     */
    public void teken(Graphics g, int x, int y)
    {
        g.setColor(vulkleur);
        g.fillRect(x, y, Wereld.VAKGROOTTE, Wereld.VAKGROOTTE);
        g.setColor(lijnkleur);
        g.drawRect(x, y, Wereld.VAKGROOTTE, Wereld.VAKGROOTTE);
    }

}

