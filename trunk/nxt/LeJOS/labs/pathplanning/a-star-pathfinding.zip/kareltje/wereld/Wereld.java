/*
 * Wereld.java
 * 
 * Created on 23 september 2004, 14:20
 */

package wereld;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class JBord extends javax.swing.JPanel
{
    private Wereld deWereld;
    
    public JBord(Wereld w)
    {
        super();
        deWereld = w;
    }
    
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        if (deWereld == null)
        {
            // skip;
        } else
        {
            deWereld.teken(g);
        }
    }
}

/**
 * De wereld waarin het robotprogramma zich afspeelt.
 */
public class Wereld extends javax.swing.JFrame

{
    /**
     * De <code>breedte</code> van de wereld, het aantal vakjes
     */
    public int breedte;

    /**
     * De <code>hoogte</code> van de wereld, het aantal vakjes
     */
    public int hoogte;
    
    
    public boolean start = false;
    
    public int riddersKlaar = 0;
    
    /**
     * De boolean <code>breedte</code> geeft aan of er gelogd wordt
     */
    private boolean logging = true;

    private WereldObject[][] bord;

    /**
     * 
     */
    public WereldObject[][] piepballen;

    private WereldObject[][] robots;
    
    private Robot[] actors;
    
    private int aantalActors;

    
    /**
     * <code>VAKGROOTTE</code> is de grootte in pixels van een vakje
     */
    public static int VAKGROOTTE = 16;


    /**
     * Maak een wereld met de default inrichting, beschreven in startwereld
     */
 

    /**
     * Maak een Wereld met een eigen inrichting, die je beschrijft met een eigen String.
     * 
     * @param s String die de wereld beschrijft. Deze bestaat uit een reeks
     * characters, ieder character staat voor een vakje. Doe een x voor een muur, o voor een
     * piepbal, een punt voor gras. Het opbouwen gaat per regel. Een regel sluit je af met 
     * <code>\n</code>, daarna wordt verdergegaan met de volgende regel.
     */
    public Wereld(String s)
    {
        creeerWereld(s);
    }

    /**
     * Deze methode voert het daadwerkelijke maken van de wereld uit.
     * 
     * @param s
     */
    private void creeerWereld(String s)
    {
        try
        {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e)
        {}

        actors = new Robot[8];
        aantalActors = 0;
        wereldUitString(s);
        setSize(500, 800);
        initComponents();
        pack();
        setVisible(true);

        running = false;
        stepState = NOTSTARTED;
        logTextArea.append("De wereld is klaar en gestart!");
    }

    /**
     * Hulpmethode bij het opbouwen van de wereld
     * @param s
     */
    private void wereldUitString(String s)
    {
        breedte = 0;
        hoogte = 0;
        int x = 0;
        int y = 0;

        // bepaal hoogte en breedte van de wereld
        for (int i = 0; i < s.length(); i++)
        {

            char c = s.charAt(i);
            if (c == '\n')
            {
                y = y + 1;
                x = 0;
            } else
            {
                x = x + 1;
            }
            
            if (hoogte < y)
                hoogte = y;
            if (breedte < x)
                breedte = x;
        }
        
        hoogte++;

        // maak de wereld
        bord = new WereldObject[breedte][hoogte];
        piepballen = new WereldObject[breedte][hoogte];
        robots = new WereldObject[breedte][hoogte];

        // initialiseer de wereld
        for (int i = 0; i < breedte; i++)
        {
            for (int j = 0; j < hoogte; j++)
            {
                bord[i][j] = new Gras(i, j);
                piepballen[i][j] = null;
                robots[i][j] = null;
            }
            ;
        }

        // vul de wereld
        x = 0;
        y = 0;
        for (int i = 0; i < s.length(); i++)
        {
            char c = s.charAt(i);
            if (c == 'm')
            {
                bord[x][y] = new Muur(x, y);
            } else if (c == 'o')
            {
                piepballen[x][y] = new Piepbal(x, y);
            } else if (c == 'h')
            {
                bord[x][y] = new Bos(x, y);
            } else if (c == 'z')
            {
                bord[x][y] = new Zand(x, y);
            } else if (c == 'b')
            {
                bord[x][y] = new Brug(x, y);
            } else if (c == 'w')
            {
                bord[x][y] = new Water(x, y);
            }
            if (c == '\n')
            {
                y = y + 1;
                x = 0;
            } else
            {
                x = x + 1;
            }
        }
    }
    
    /**
     * Zet het log van de Wereld aan/uit.
     * Als het log uit staat, verschijnen alleen de dingen die een Robot zegt
     * in het logvenster, niet de stappen etc.
     * 
     * @param b boolean: true is aan, false is uit.
     */
    public void setLogging(boolean b)
    {
        logging = b;
    }
    
    /**
     * Verplaats een WereldObject (Robot, Piepbal, ...) naar de opgegeven positie
     * <br/>
     * NB: Het object moet al in de wereld staan!
     * 
     * @param o het WereldObject
     * @param pos_x de horizontale index van het vakje waar het heen moet
     * @param pos_y de verticale index van het vakje waar het heen moet
     */
    public void verplaats(WereldObject o, int pos_x, int pos_y)
    {
        if (o instanceof Gras)
        {
            bord[o.pos_x][o.pos_y] = new Gras(pos_x, pos_y);
            bord[pos_x][pos_y] = o;
        } else if (o instanceof Zand)
        {
            bord[o.pos_x][o.pos_y] = new Zand(pos_x, pos_y);
            bord[pos_x][pos_y] = o;
        } else if (o instanceof Brug)
        {
            bord[o.pos_x][o.pos_y] = new Brug(pos_x, pos_y);
            bord[pos_x][pos_y] = o;
        } else if (o instanceof Muur)
        {
            bord[o.pos_x][o.pos_y] = new Gras(pos_x, pos_y);
            bord[pos_x][pos_y] = o;
        } else if (o instanceof Water)
        {
            bord[o.pos_x][o.pos_y] = new Gras(pos_x, pos_y);
            bord[pos_x][pos_y] = o;
        } else if (o instanceof Bos)
        {
            bord[o.pos_x][o.pos_y] = new Gras(pos_x, pos_y);
            bord[pos_x][pos_y] = o;
        } else if (o instanceof Piepbal)
        {
            piepballen[o.pos_x][o.pos_y] = null;
            piepballen[pos_x][pos_y] = o;
        } else if (o instanceof Robot)
        {
            robots[o.pos_x][o.pos_y] = null;
            robots[pos_x][pos_y] = o;
        } else
        {
            // skip;
        }
        o.pos_x = pos_x;
        o.pos_y = pos_y;
    }

    /**
     * Kijk of er Gras ligt op het vakje met de opgegeven index
     * 
     * @param pos_x de horizontale index van het vakje
     * @param pos_y de verticale index van het vakje
     * 
     * @return boolean, true als er Gras ligt
     */
    public boolean gras(int pos_x, int pos_y)
    {
        return (bord[pos_x][pos_y] instanceof Gras);
    }

    public boolean zand(int pos_x, int pos_y)
    {
        return (bord[pos_x][pos_y] instanceof Zand);
    }
 
    public boolean brug(int pos_x, int pos_y)
    {
        return (bord[pos_x][pos_y] instanceof Brug);
    }
    
    int kasteelPlekX = 29;
    int kasteelPlekY = 2;    
    
    public int getKasteelPlekX()
    {
        return kasteelPlekX;
    }

    public int getKasteelPlekY()
    {
        return kasteelPlekY;
    }

    public void setKasteelPlekX(int nummer)
    {
        kasteelPlekX = nummer;
    }
    
    public void setKasteelPlekY(int nummer)
    {
        kasteelPlekY = nummer;
    }
    
    /**
     * Kijk of er een Muur staat op het vakje met de opgegeven index
     * 
     * @param pos_x de horizontale index van het vakje
     * @param pos_y de verticale index van het vakje
     * 
     * @return boolean, true als er een Muur staat
     */
    public boolean muur(int pos_x, int pos_y)
    {
        return (bord[pos_x][pos_y] instanceof Muur);
    }

    public boolean bos(int pos_x, int pos_y)
    {
        return (bord[pos_x][pos_y] instanceof Bos);
    }
 
    public boolean water(int pos_x, int pos_y)
    {
        return (bord[pos_x][pos_y] instanceof Water);
    }    
    
    /**
     * Kijk of er een Robot staat op het vakje met de opgegeven index
     * 
     * @param pos_x de horizontale index van het vakje
     * @param pos_y de verticale index van het vakje
     * 
     * @return boolean, true als er een Robot staat
     */
    public boolean robot(int pos_x, int pos_y)
    {
        return (robots[pos_x][pos_y] instanceof Robot);
    }

    /**
     * Kijk of er een piepbal ligt op het vakje met de opgegeven index
     * 
     * @param pos_x de horizontale index van het vakje
     * @param pos_y de verticale index van het vakje
     * 
     * @return boolean, true als er een piepbal ligt
     */
    public boolean piepbal(int pos_x, int pos_y)
    {
        return (piepballen[pos_x][pos_y] instanceof Piepbal);
    }

    /**
     * Kijk of het vakje met de opgegeven index bezet is met robot of een obstakel
     * 
     * @param pos_x de horizontale index van het vakje
     * @param pos_y de verticale index van het vakje
     * 
     * @return boolean, true als het vakje bezet is
     */
    public boolean bezet(int pos_x, int pos_y)
    {
        return (robot(pos_x, pos_y) || muur(pos_x, pos_y) || bos(pos_x, pos_y) || water(pos_x, pos_y));
    }

    
    /**
     * Kijk of het vakje met de opgegeven index bezet is met obstakel muur, Bos of water
     * 
     * @param pos_x de horizontale index van het vakje
     * @param pos_y de verticale index van het vakje
     * 
     * @return boolean, true als het vakje bezet is
     */    
     public boolean obstakel(int pos_x, int pos_y)
    {
        return (muur(pos_x, pos_y) || bos(pos_x, pos_y) || water(pos_x, pos_y));
    }

    
    /**
     * Zet een nieuw WereldObject (Robot, Piepbal, ...) in de Wereld
     * <br/> Gebruik verplaats om een WereldObject dat al in de Wereld staat
     * te verplaatsen
     * 
     * @param o het WereldObject
     * @param pos_x de horizontale index van het vakje waar het heen moet
     * @param pos_y de verticale index van het vakje waar het heen moet
     */
    public void plaats(WereldObject o, int pos_x, int pos_y)
    {
        o.pos_x = pos_x;
        o.pos_y = pos_y;
        if (o.pos_x < 0 || o.pos_x >= breedte || o.pos_y < 0 || o.pos_y >= hoogte)
        {
            //skip;
        } else if (o instanceof Gras)
        {
            bord[o.pos_x][o.pos_y] = o;
        } else if (o instanceof Zand)
        {
            bord[o.pos_x][o.pos_y] = o;
        } else if (o instanceof Brug)
        {
            bord[o.pos_x][o.pos_y] = o;
        } else if (o instanceof Muur)
        {
            bord[o.pos_x][o.pos_y] = o;
        } else if (o instanceof Water)
        {
            bord[o.pos_x][o.pos_y] = o;
        } else if (o instanceof Bos)
        {
            bord[o.pos_x][o.pos_y] = o;
        } else if (o instanceof Piepbal)
        {
            piepballen[o.pos_x][o.pos_y] = o;
        } else if (o instanceof Robot)
        {
            if (aantalActors < 8)
            {
                actors[aantalActors] = (Robot)o;
                aantalActors++;
                robots[o.pos_x][o.pos_y] = o;
            }
        } else
        {
            // skip;
        }
        o.setWereld(this);
    }

    /**
     * Haal een WereldObject uit de Wereld.
     * <br/>
     * NB: Fout, neemt nu alleen piepballen.....
     * 
     * @param pos_x
     * @param pos_y
     * @return het opgepakte WereldObject (piepbal)
     */
    WereldObject neem(int pos_x, int pos_y)
    {
        if (piepbal(pos_x, pos_y))
        {
            WereldObject o = piepballen[pos_x][pos_y];
            piepballen[pos_x][pos_y] = null;
            return o;
        } else
        {
            return null;
        }
    }

    /**
     * Teken de Wereld.
     * 
     * @param g
     *                De graphics waar de robot getekend wordt.
     */
    public void teken(Graphics g)
    {
        for (int i = 0; i < breedte; i++)
        {
            for (int j = 0; j < hoogte; j++)
            {
                bord[i][j].teken(g, i * VAKGROOTTE, j * VAKGROOTTE);
                if (piepballen[i][j] != null)
                {
                    piepballen[i][j].teken(g, i * VAKGROOTTE, j * VAKGROOTTE);
                }
            }
        }
        for (int i = 0; i < breedte; i++)
        {
            for (int j = 0; j < hoogte; j++)
            {
                if (robots[i][j] != null)
                {
                    robots[i][j].teken(g, i * VAKGROOTTE, j * VAKGROOTTE);
                }
            }
        }
    }
    
// -------- Verwerking van het hoofdprogramma ------------------------------------------------

    /**
     * <code>slaaptijd</code> is de pauze tussen twee stappen
     */
    private int slaaptijd = 100;

    /**
     * Hoofdprogramma nog niet gestart
     */
    public static final int NOTSTARTED = 0;
    
    /**
     * Hoofdprogramma loopt met stapjes
     */
    public static final int ANIMPAUSE = 201;
    
    /**
     * Hoofdprogramma wacht na elke stap
     */
    public static final int ANIMSTEP = 202;
    
    /**
     * <code>stepState</code> is de toestand van het hoofdprogramma, 
     * NOTSTARTED, ANIMPAUSE of ANIMSTEP
     */
    private int stepState;
    
    /**
     * <code>running</code> geeft aan of de thread loopt
     */
    private boolean running;
    
    /**
     * Zet de slaaptijd voor de pauzes tussen stappen
     * 
     * @param ms slaaptijd in milliseconden
     */
    public void setSlaaptijd(int ms)
    {
        slaaptijd = ms;
    }
    
    public int getSlaaptijd()
    {
        return slaaptijd;
    }
    
    public int getStepState()
    {
        return stepState;
    }

    void addLineToLog(String line, boolean logalways)
    {
        // write to log-Textarea if 1. logging is on 2. message must be logged always (zeg).
        if ( logging || logalways )
        {   
            SwingUtilities.invokeLater (new WriterToLog(line, logTextArea, logScrollBar));
        }
    }
    
    /**
     * start het hoofdprogramma in een aparte Thread
     */
    private void startProgramma()
    {
        for (int i=0; i<aantalActors; i++)
        {   actors[i].startProgramma();
        }
        running = true;
    }

    /**
     * zet execute-state in doorlopend, met pauzes
     */
    private void speelProgramma() {
        
        if (!running) {    
            startProgramma();
        }
        
        for (int i=0; i<aantalActors; i++)
        {   actors[i].setStopper(false);
        }
        stepState = ANIMPAUSE;
    }

    /**
     * zet execute-state in wachten bij stap
     */
    private void stapProgramma() {
            
        if (!running) {    
            startProgramma();
        }
        
        if (stepState == ANIMSTEP)
        {
            for (int i=0; i<aantalActors; i++)
            {   
                actors[i].setStopper(false);
            }
        } else {   
            stepState = ANIMSTEP;       // ga naar stap-modus, blokkeer next step
            for (int i=0; i<aantalActors; i++)
            {   
                actors[i].setStopper(true);
            }
        }
    }

    /**
     * Wordt door de Robot aangeroepen als er een fout optreedt (stoot zijn neus, etc)
     * 
     * @param s de foutmelding
     */
    public void foutOpgetreden(String s)
    {
        addLineToLog("", true);
        addLineToLog("**** FOUT OPGETREDEN ****", true);
        addLineToLog(s, true);
        addLineToLog("", true);
     }

    /**
     * Stop de gehele applicatie
     */
    private void stop()
    {
        System.exit(0);
    }
    

    
// -------- Maak het frame nmet de diverse panels en tekstveld incl event handlers ---------------

    private JScrollPane logPanel;
    
    private JTextArea logTextArea;
    
    private JScrollBar logScrollBar;
    
    /**
     * <code>knoppenPanel</code> is het Panel met de besturingsknoppen onderin
     */
    private javax.swing.JPanel knoppenPanel;

    /**
     * <code>wereldPanel</code> is het Panel waarin de wereld getekend wordt
     */
    private javax.swing.JPanel wereldPanel;

    /**
     * <code>startKnop</code> start het hoofdprogramma
     */
       /**
     * <code>loopKnop</code> laat het hoofdprogramma doorlopen met pauzes
     */
    private javax.swing.JButton loopKnop;

    /**
     * <code>stapKnop</code> laat het hoofdprogramma pauzeren bij elke stap
     */
    private javax.swing.JButton stapKnop;

    /**
     * <code>exitKnop</code> stopt de applicatie
     */
    private javax.swing.JButton exitKnop;

    /**
     * Deze methode bouwt de user-interface.
     */
    private void initComponents()
    {
        // eigenschappen van het frame
        setTitle("Koning Karel en de verloren schat");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter()
        {
            public void windowClosing(java.awt.event.WindowEvent evt)
            {
                exitForm(evt);
            }
        });

        // bouw het paneel met de knoppen
        knoppenPanel = new javax.swing.JPanel();
        knoppenPanel.setLayout(new BoxLayout(knoppenPanel, BoxLayout.X_AXIS));
        knoppenPanel.setBorder(new javax.swing.border.LineBorder(new Color(0, 0, 0), 1, true));


        loopKnop = new JButton("Loop");
        loopKnop.setHorizontalAlignment(SwingConstants.LEFT);
        loopKnop.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent evt)
            {
                loopActionPerformed(evt);
            }
        });
        loopKnop.setEnabled(true);
        knoppenPanel.add(loopKnop);

        stapKnop = new JButton("Stap");
        stapKnop.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent evt)
            {
                stapActionPerformed(evt);
            }
        });
        stapKnop.setEnabled(true);
        knoppenPanel.add(stapKnop);

        exitKnop = new javax.swing.JButton("Exit");
        exitKnop.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        exitKnop.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                stopActionPerformed(evt);
            }
        });
        knoppenPanel.add(exitKnop);
        
        // Panel voor het log
        logTextArea = new JTextArea(10, 48);
        logTextArea.setEditable(false);
        logTextArea.setFont(new Font("Arial", Font.PLAIN, 12));
        logTextArea.setFocusable(false);
        logTextArea.setRequestFocusEnabled(false);
        logTextArea.setVerifyInputWhenFocusTarget(false);
        //logTextArea.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        JScrollPane logPanel = new JScrollPane(logTextArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER );
        logScrollBar = logPanel.getVerticalScrollBar();
        
        // paneel voor de wereld
        wereldPanel = new JBord(this);
        wereldPanel.setBackground(new java.awt.Color(102, 204, 0));
        wereldPanel.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        wereldPanel.setFocusable(false);
        wereldPanel.setMinimumSize(new java.awt.Dimension(breedte * VAKGROOTTE, hoogte * VAKGROOTTE));
        wereldPanel.setPreferredSize(new java.awt.Dimension(breedte * VAKGROOTTE, hoogte * VAKGROOTTE));

        getContentPane().add(wereldPanel, java.awt.BorderLayout.CENTER);
        getContentPane().add(knoppenPanel, java.awt.BorderLayout.NORTH);
        getContentPane().add(logPanel, java.awt.BorderLayout.SOUTH);
    }


    private void loopActionPerformed(java.awt.event.ActionEvent evt)
    {
       
        speelProgramma();
    }

    private void stapActionPerformed(java.awt.event.ActionEvent evt)
    {
        stapProgramma();
    }

    private void stopActionPerformed(java.awt.event.ActionEvent evt)
    {
        stop();
    }

    private void exitForm(java.awt.event.WindowEvent evt)
    {
        stop();
    }
}

