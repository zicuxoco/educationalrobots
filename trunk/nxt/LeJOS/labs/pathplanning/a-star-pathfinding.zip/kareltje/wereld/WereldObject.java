/*
 * WereldObject.java
 * 
 * Created on 24 januari 2005, 17:08
 */

package wereld;

import java.awt.*;

/**
 * De algemene klasse voor alle objecten in de wereld
 */
public abstract class WereldObject
{
    /**
     * De wereld waar dit object in staat
     */
    protected Wereld mijnWereld;
    
    /**
     * <code>pos_x</code> horizontale index van het vakje waar dit object staat
     * 0 is helemaal links.
     */
    protected int pos_x = 0;

    /**
     * <code>pos_y</code> verticale index van het vakje waar dit object staat
     * 0 is helemaal boven.
     */
    protected int pos_y = 0;
    
    /**
     * vulkleur bij tekenen
     */
    protected Color vulkleur = new Color(255, 255, 255);

    /**
     * lijnkleur bij tekenen
     */
    protected Color lijnkleur = new Color(0, 0, 0);

    /**
     * Maak een WereldObject met de opgegeven positie
     * 
     * @param x x-index in de Wereld
     * @param y y-index in de Wereld
     */
    public WereldObject(int x, int y)
    {
        pos_x = x;
        pos_y = y;
    }
    
    /**
     * Vertel het object in welke Wereld het staat
     * <br/>
     * Dit wordt automatisch gedaan bij het plaatsen van een object
     * 
     * @param w de wereld
     */
    public void setWereld(Wereld w)
    {
        mijnWereld = w;
    }

    /**
     * Zet de vulkleur waarmee het object getekend wordt dmv RGB-waarden.
     * 
     * @param r de waarde van de rood-component, van 0 t/m 255
     * @param g de waarde van de groen-component, van 0 t/m 255
     * @param b de waarde van de blauw-component, van 0 t/m 255
     */
    public void setVulkleur(int r, int g, int b)
    {
        vulkleur = new Color(r, g, b);
    }

    /**
     * Zet de vulkleur waarmee het object getekend wordt dmv RGB-waarden.
     * 
     * @param r de waarde van de rood-component, van 0 t/m 255
     * @param g de waarde van de groen-component, van 0 t/m 255
     * @param b de waarde van de blauw-component, van 0 t/m 255
     */
    public void setLijnkleur(int r, int g, int b)
    {
        lijnkleur = new Color(r, g, b);
    }

    /**
     * Teken deze robot.
     * 
     * @param g
     *                De graphics waar de robot getekend wordt.
     * @param x
     *                De x locatie op de graphics waar de robot getekend wordt.
     * @param y
     *                De y locatie op de graphics waar de robot getekend wordt.
     */
    public abstract void teken(Graphics g, int x, int y);

}

