import wereld.*;


public class KoningKarel extends Robot
{
    public KoningKarel(String s) {
        super(s);
    }
    
    
    public void hoofdProgramma() {

        mijnWereld.start = schreeuw("Ridders, ik ben mijn goud kwijt. Er op uit!!");
        
        wachtOpKlaar();
        
    }
    
    
    public void wachtOpKlaar() {
        
        if (mijnWereld.riddersKlaar == 4) {
                schreeuw("Yeah, ik heb mijn schat weer terug!");
        } else {
            slaap(1);
            wachtOpKlaar();
        }
    
    }
    
    
}
