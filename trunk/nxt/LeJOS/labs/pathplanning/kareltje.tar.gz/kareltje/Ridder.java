import wereld.*;


public class Ridder extends Robot {
   
    public Ridder(String s) {
        super(s);
    }
    
    // declareerd globaal variable voor het aantal goudklompen
    int aantalGoudklompen = 4; // per ridder
    
    // declareerd een globale array om de posities van de goudklompen bij te houden
    String goudklompPos[] = new String[aantalGoudklompen];
    
    // declareerd en initialiseert globale variable voor het ridder nummer (globale variabel omdat deze ingesteld moet worden voordat hoofdprogramma aangeroepen word)
    //int ridderNummer;
    
    public void hoofdProgramma() {     
        
        // wacht tot de ridders gestart worden
        if (mijnWereld.start) {

            slaap((ridderNummer * 2) + ridderNummer);
           
            //voor ieder hokje uit de array goudklompPos (dus voor ieder geplaatst goudklompje)
            for (String pos : goudklompPos) {
                String [] splitGoudklompPos; //declareerd array voor het splitten van de goudklomp positie
                splitGoudklompPos = pos.split("\\,"); //split de string op komma om de x en y as los van elkaar te kunnen gebruiken
            
                zeg("Haalt bal op van positie: " + splitGoudklompPos[0] + ", " + splitGoudklompPos[1]);
            
                navigeerNaar(Integer.parseInt(splitGoudklompPos[0]),Integer.parseInt(splitGoudklompPos[1])); //roept navigeer naar functie aan met x en y
           
                //als de ridder op de goudklomp staat
                if (oppiepbal()) {
                    pakpiepbal();
                    navigeerNaarKasteel(); //navigeert naar een vrije plek in het kasteel
                    legGoudklomp(); 
                }
            
            }
            navigeerNaar(21,10-ridderNummer);   
            navigeerNaar(19,10-ridderNummer);
            draai("oost");
            zeg("klaar");
            mijnWereld.riddersKlaar++;
        } else {
            slaap(1);
            hoofdProgramma();
        }
    }
    
    

    /**
    * De methode 'ridderPlaatsGoud' roept voor het aantal goudklompen de functie plaatsRandomGoudklomp en plaatst de positie van de goudklompen in een globale array
    * 
    * @return void
    */    
    public void plaatsGoudKlompen() {
        for (int i = 0; i < aantalGoudklompen; i++) {
            goudklompPos[i] = plaatsRandomGoudklomp();
        }
    }
    
    
    /**
    * De methode 'plaatsRandomGoudklomp' zoekt ergens in de wereld een vrije plek en plaatst het goudklompje erop
    * 
    * @return String, de x komma y de positie van de goudklomp
    */    
    public String plaatsRandomGoudklomp() {
        int goudklompX = (int) (Math.random() * mijnWereld.breedte);
        int goudklompY = (int) (Math.random() * mijnWereld.hoogte);
        
        if (!mijnWereld.bezet(goudklompX, goudklompY) && !mijnWereld.piepbal(goudklompX, goudklompY) && !mijnWereld.zand(goudklompX, goudklompY) && !mijnWereld.brug(goudklompX, goudklompY)) {
            Piepbal goudklomp =  new Piepbal(goudklompX, goudklompY);
            mijnWereld.plaats(goudklomp, goudklompX, goudklompY);
            mijnWereld.repaint();
            return goudklompX + "," + goudklompY;
        } else {
            return plaatsRandomGoudklomp();
        }
    }   
    
        
     /**
     * De methode 'navigeerNaar' navigeert naar opgegeven x en y as
     * 
     * @param dest_x is de horizontale index van het bestemmings vakje
     * @param dest_y is de verticale index van het bestemmings vakje
     * 
     * @return void
     */   
     public void navigeerNaar(int destX, int destY) {
        
        //zolang de positie van de robot niet op zijn bestemming is stapt hij in de goede richting voor de kortste weg
        while (getX() != destX || getY() != destY) {
            stapSpeciaal(destX, destY);
        }
        
    }

    
     /**
     * De methode 'navigeerNaarKasteel' navigeert naar een vrije plek in het kasteel voor de goudklomp te plaatsen
     * Blijft zichzelf aanroepen tot de karel op de vrije plek is. Voor ieder stap kijkt hij ook of hij een nieuwe vrije plek moet aanhouden
     * 
     * @return void
     */   
     public void navigeerNaarKasteel() {
        int kasteelPlekX = mijnWereld.getKasteelPlekX();
        int kasteelPlekY = mijnWereld.getKasteelPlekY();
        if (getX() != kasteelPlekX || getY() != kasteelPlekY) {
            stapSpeciaal(kasteelPlekX, kasteelPlekY);
            navigeerNaarKasteel();
        }
        
    }
    
    
    /**
    * De methode 'legGoudklomp' legt goudklomp neer en stelt de vrije plek in het kasteel overnieuw in
    * 
    * @return void
    */      
    public void legGoudklomp() {
        legpiepbal();
        mijnWereld.setKasteelPlekX(mijnWereld.getKasteelPlekX()-1);
        if (mijnWereld.getKasteelPlekX() < 26) {
            mijnWereld.setKasteelPlekY(mijnWereld.getKasteelPlekY()+1);
            mijnWereld.setKasteelPlekX(29);
        }
    }   
                   
    
    /**
    * De methode 'stapSpeciaal' bepaald een vrije route naar de bestemming en stapt vervolgens in de goede richting van de route
    * Gcost is het aantal stappen vanaf begin punt
    * Hcost is het aantal stappen rechtstreeks naar de bestemming (zonder obstakels)
    * Fcost is Gcost + Hcost. Hoe lager de Fcost hoe dichter bij de bestemming
    * 
    * @param dest_x is de horizontale index van het bestemmings vakje
    * @param dest_y is de verticale index van het bestemmings vakje
    * 
    * @return void
    */       
    public void stapSpeciaal(int destX, int destY) {

        //haalt wereld breedte en hoogte op
        int wereldBreedte = mijnWereld.breedte;
        int wereldHoogte = mijnWereld.hoogte;
                
        boolean obstakelLijst[][] = new boolean [wereldBreedte][wereldHoogte]; //array voor alle velden met obstakel
        //loopt alle velden na om te kijken of ze een obstakel zijn
        for (int x = 0; x < wereldBreedte; x++) {
            for (int y = 0; y < wereldHoogte; y++) {
                obstakelLijst[x][y] = mijnWereld.obstakel(x,y);
            }
        }   
        

        //declareren en initialiseren nodige array's en variablen
        boolean openVeldenXY[][] = new boolean [wereldBreedte][wereldHoogte]; //array voor alle open velden op basis van x en y;
        int openVelden[] = new int [wereldBreedte*wereldHoogte]; //array voor alle velden die getest moeten worden
        int openVeldX[] = new int [wereldBreedte*wereldHoogte]; //houd X as bij voor de velden uit de openVelden array
        int openVeldY[] = new int [wereldBreedte*wereldHoogte]; //houd Y as bij voor de velden uit de openVelden array

        boolean geslotenVelden[][] = new boolean [wereldBreedte][wereldHoogte]; //array voor alle gesloten velden
        
        int gCost[][] = new int [wereldBreedte][wereldHoogte]; //array voor de Gcost
        int hCost[][] = new int [wereldBreedte][wereldHoogte]; //array voor de Hcost
        int fCost[][] = new int [wereldBreedte][wereldHoogte]; //array voor de Fcost
        
        int parentX[][] = new int [wereldBreedte][wereldHoogte]; //array voor de x-as van de parent
        int parentY[][] = new int [wereldBreedte][wereldHoogte]; //array voor de y-as van de parent
        
        int startX = getX(); //vraagt x positie van robot op en gebruikt deze als start plek voor de route
        int startY = getY(); //vraagt y positie van robot op en gebruikt deze als start plek voor de route
        
        boolean routeBepaald = false; //geeft aan of de route bepaald is
        
        int aantalOpenVelden, openVeldenId, vorigeX, vorigeY, veldWissel, x = 0, y = 0, routeX, routeY, tempX;
                       
        //initialiseert variablen en arrays voor eerste open veld: het begin punt
        openVeldenId = 1;
        aantalOpenVelden = 1;
        openVelden[aantalOpenVelden] = openVeldenId;
        openVeldX[openVeldenId] = startX;
        openVeldY[openVeldenId] = startY;
        
        gCost[startX][startY] = 0;
                
        
        while (aantalOpenVelden > 0) {
        
                //slaat X en Y van vorige veld tijdelijk op
                vorigeX = openVeldX[openVelden[1]];
                vorigeY = openVeldY[openVelden[1]];
                
                //als het vorige bekeken veld het eind punt is dan stopt hij met de while
                if (vorigeX == destX && vorigeY == destY) {
                    routeBepaald = true; //stelt in dat de route is bepaald
                    break;    
                }
                
                geslotenVelden[vorigeX][vorigeY] = true; //stelt vorige veld (de eerste uit de lijst) als gesloten in
                openVelden[1] = openVelden[aantalOpenVelden]; //gooit vorige veld (eerste uit de lijst) uit de open lijst door de onderste naar boven te verplaatsen 
                aantalOpenVelden--; //en vervolgens ��n veld van het aantal velden aftrekken
              
                // voor alle 4 de stap mogelijkheden om het vorige veld heen
                for (int k = 1; k <= 4; k++){
                    if (k == 1) { // bij 1: pak veld boven vorige veld
                        x = vorigeX;
                        y = vorigeY - 1;
                    } else if (k == 2) { // bij 2: pak veld rechts van vorige veld
                        x = vorigeX + 1;
                        y = vorigeY;
                    } else if (k == 3) { // bij 3: pak veld onder van vorige veld
                        x = vorigeX;
                        y = vorigeY + 1;
                    } else if (k == 4) { // bij 4: pak veld links van vorige veld
                        x = vorigeX - 1;
                        y = vorigeY;   
                    }
 
                    //kijkt of de veld mogelijkheid niet buiten de wereld valt
                    if (x >= 0 && y >= 0 && x < wereldBreedte && y < wereldHoogte) {
 
                        //kijkt of de veld mogelijkheid niet gesloten is en niet bezet is
                        if (!obstakelLijst[x][y] && !geslotenVelden[x][y]) {
                            
                            // als veld mogelijkheid geen open veld is
                            if (!openVeldenXY[x][y]) {
                                    
                                    //voegt nieuwe veld toe aan de openlijst
                                    aantalOpenVelden++; 
                                    openVeldenId++;
                                    openVelden[aantalOpenVelden] = openVeldenId;
                                    openVeldX[openVeldenId] = x;
                                    openVeldY[openVeldenId] = y;
                                    openVeldenXY[x][y] = true;
                                    
                                    gCost[x][y] = gCost[vorigeX][vorigeY] + 1; //stelt Gcost in voor het nieuwe veld (Gcost van zijn parent + 1)
                                    hCost[x][y] = berekenHcost(x, y, destX, destY); //berekend Hcost en stelt deze in
                                    fCost[x][y] = gCost[x][y] + hCost[x][y]; //berekend Fcost (Gcost + Hcost)
                                    
                                    parentX[x][y] = vorigeX; //stelt vorige veld in als parent 
                                    parentY[x][y] = vorigeY; //stelt vorige veld in als parent 
                                    
                                    
                            } else { // als veld mogelijkheid wel al open veld is

                                    // als de G cost van de nieuwe route korter is..
                                    if (gCost[vorigeX][vorigeY] + 1 < gCost[x][y]) {
                                        parentX[x][y] = vorigeX; //stelt vorige veld nieuwe parent in
                                        parentY[x][y] = vorigeY; //stelt vorige veld nieuwe parent in
                                        gCost[x][y] = gCost[vorigeX][vorigeY] + 1; //verander naar de nieuwe G cost
                                        fCost[x][y] = gCost[x][y] + hCost[x][y]; //berekend nieuwe Fcost (Gcost + Hcost)
                                    }
  
                            }
                            
                            //zet volgorde openVelden array van laag naar hoog op basis van hun F cost
                            for (int j = 1; j < aantalOpenVelden; j++) {
                                for (int i = 1; i < aantalOpenVelden; i++) {
                                    if (fCost[openVeldX[openVelden[i]]][openVeldY[openVelden[i]]] > fCost[openVeldX[openVelden[i+1]]][openVeldY[openVelden[i+1]]]) {
                                        veldWissel = openVelden[i];
                                        openVelden[i] = openVelden[i+1];
                                        openVelden[i+1] = veldWissel;
                                    }
                                }
                            }
                            
                        }
                        
                    }
                }
                
        } //einde while voor alle open velden
       
        
        //als de route bepaald is
        if (routeBepaald) {
            routeX = destX; 
            routeY = destY;
            
            //loopt route na van bestemming terug naar het startveld door van ieder veld zijn parent te pakken en stopt bij het eerste veld in de route na het start veld
            while ((parentX[routeX][routeY] != startX) || (parentY[routeX][routeY] != startY)) {
                    tempX = parentX[routeX][routeY];        
                    routeY = parentY[routeX][routeY];
                    routeX = tempX;               
            }
            
            //stapt naar het volgende veld
            stapRichting(routeX, routeY);
        }
        
        
     }
    
    
     /**
     * De methode 'berekenHcost' berekend de H Cost (hoeveel stappen het is rechtstreeks naar de bestemming (zonder obstakels))
     * 
     * @param x is de horizontale index van het huidige vakje
     * @param y is de verticale index van het huidige vakje
     * 
     * @return int, aantal stappen rechtstreeks naar de bestemming
     */    
     public int berekenHcost(int x, int y, int destX, int destY) {
        int cost = 0;
        
        if (destY < y) {
            cost = cost + (y - destY);
        } else if (destY > y) {
            cost = cost + (destY - y);       
        }
        
        if (destX > x){
            cost = cost + (destX - x);
        } else if (destX < x){
            cost = cost + (x - destX);
        }
        
        return cost;
     }
    
    
     /**
     * De methode 'stapRichting' zet kareltje ��n stap in de richting van de opgegeven x en y as
     * 
     * @param x is de horizontale index van het huidige vakje
     * @param y is de verticale index van het huidige vakje
     * 
     * @return void
     */  
     public void stapRichting(int richtingX, int richtingY) {
         if (richtingY < getY()) {
             draai("noord");
             stap(1);
         } else if (richtingX > getX()) {
             draai("oost");    
             stap(1);
         } else if (richtingY > getY()) {
             draai("zuid");
             stap(1);    
         } else if (richtingX < getX()) {
             draai("west");
             stap(1);
         }
    }
 

}
