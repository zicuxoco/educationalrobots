import wereld.*;

public class Landgoed extends Wereld
{

    static String nieuweKaart = 
             ("...hhhhhhhhhh.........wwmmwwwwmmww.........\n" 
            + "...h........h.........wwmmmmmmmmww.........\n" 
            + "...h.hhhhhh.h..wwwwwwwwwwmzzzzmwww.........\n" 
            + "...h.h....h.h.wwwwwwwwwwwmzzzzmww..........\n" 
            + "...h.h.hh.h.h.wwmmwmmmmmwmzzzzmww..hhhh....\n" 
            + "...h.h.h..h.h.wwmmmmzzzmmmzzzzmwww..hh..hhh\n" 
            + ".h.h.h.hhhh.h.wwwmzzzzzzzzzmmmmmww..hhhhhh.\n" 
            + ".h.h.h......h..wwmzzzzzzzmmmwwmmww....hhh..\n" 
            + "hh.h.hhhhhhhh..wwmzzzzzzzmwwwwwww.....hhhh.\n"
            + "h....h.h.......wwmzzzzzzzmwww..............\n" 
            + "h.hhhh.hhh.hhh.wwmzzzzzzzmww.......hhhh....\n"
            + ".....h.........wwmzzzzzzzmww.....wwhhhhhhh.\n"
            + ".....hhh......wwwmzzmzmzzmwww....wwwwhhhhh.\n" 
            + "hhh.......zhh.wwmmmmmzmmmmmww.....wwwhhhh..\n"
            + "hhhhhhhhhhzhh.wwmmwwwbwwwmmww...hhhwhhhh...\n" 
            + "hhhhhhhhhhzhhhwwwwwwwbwwwwwww..hhhhwwhhhh..\n"
            + ".....hhhhhzhhhhwwww..z..wwww....hhwwwwhhhhh\n" 
            + "........hhzhhh.......z.............hhh.hhhh\n"
            + "..........zzz.......zzzzzz.........hh......\n"
            + ".hhh........zzzzzzzzz....zzz...............\n"
            + "hhhhh........hhhz..........z...............\n"
            + "hhhhh......hhhhhz..........zzzzzzhh.www.ww.\n"
            + "whhhhh.......hhhz...........hhhhzhh..wwwww.\n"
            + "wwww.......zzzzzz.............hhzhhh..www..\n"
            + ".wwwwww..zzzhhhh.......hhh.hhhhhzzhhh..ww..\n"
            + "....wwww.z............hhhhhhhhhhhzzhhhh....\n"
            + "......wwwbww...........hhhhhhhhh..z..hh....\n"
            + "........wbwww.......zzhhhhhhhh....z........\n"
            + ".........z.www.....zzzzhhhhhhh..hhzz.......\n"
            + "......zzzz..wwww....zzzzzhhhhhhhhhhzzzzz...\n"
            + "...hhzz.......wwww....zzzhhhhhhhhhhh...zz..\n"
            + ".hhhhz..........www....hhhhh....wwwwww..zzz\n"
            + ".hhhhz...hhh.....www....hhh....wwwwwwww....\n"
            + "hhhhhz..hhhhhh....ww....hhhh..www...www....\n"
            + "hhh.zz...hhhhhhh..www....hhhh..www.........\n"
            + "....z.........hhh..wwww...hhhh.............\n"
            + "....z........hhhh....ww....................");




    //declareerd en initialiseert globale array's en variablen
    int aantalRidders = 4;
    Robot KoningKarel;
    Robot Ridder[] = new Robot[aantalRidders];

    
    public static void main(String args[]) {
        Wereld w = new Landgoed();
    }
    
      
    public Landgoed() {        
        super(nieuweKaart); 

        setSlaaptijd(50); //stelt slaaptijd tussen stappen in
        
        //plaatst Koning Karel in de wereld
        KoningKarel = new KoningKarel("Koning Karel");
        plaats(KoningKarel, 21, 5);     
        KoningKarel.setVulkleur(203, 2, 2);
        KoningKarel.draai("zuid");
             
        //plaatst voor het aantal opgegeven ridders een ridder in de wereld, geeft de ridder een nummer en plaatst voor betreffende ridder de goudklompen
        for (int i = 0; i < aantalRidders; i++) {
            Ridder[i] = new Ridder("Ridder" + i);
            plaats(Ridder[i], 19, 10 - i);   
            Ridder[i].draai("oost");
            Ridder[i].setRidderNummer(i);
            Ridder[i].plaatsGoudKlompen();
        }

        
    }

}
