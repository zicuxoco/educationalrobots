/*
 * Bos.java
 *
 * Created on 22 september 2009 door Bo Pennings
 */

package wereld;

import java.awt.*;

/**
 * Een Bos op een vakje in de Wereld
 */
public class Bos extends WereldObject
{

    /**
     * Maak een Bos op het opgegeven vakje
     * 
     * @param x
     *                de horizontale index van het vakje (vanaf links, telt vanaf 0)
     * @param y
     *                de verticale index van het vakje (vanaf boven, telt vanaf 0)
     */
    public Bos(int x, int y)
    {
        super(x, y);
        setVulkleur(0, ((int) (Math.random() * 20.0)) + 100, 0);
    }

    /**
     * Teken de heg op het scherm
     */
    public void teken(Graphics g, int x, int y)
    {
        g.setColor(vulkleur);
        g.fillRect(x, y, Wereld.VAKGROOTTE, Wereld.VAKGROOTTE);
        g.setColor(lijnkleur);
        g.drawRect(x, y, Wereld.VAKGROOTTE, Wereld.VAKGROOTTE);
    }

}

