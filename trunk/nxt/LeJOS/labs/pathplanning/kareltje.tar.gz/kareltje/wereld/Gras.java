/*
 * Gras.java
 *
 * Created on 24 januari 2005, 17:08
 */

package wereld;

import java.awt.*;

/**
 * Een grasmat op een vakje in de Wereld
 */
public class Gras extends WereldObject
{

    /**
     * Maak een grasmat op het opgegeven vakje
     * 
     * @param x
     *                de horizontale index van het vakje (vanaf links, telt vanaf 0)
     * @param y
     *                de verticale index van het vakje (vanaf boven, telt vanaf 0)
     */
    public Gras(int x, int y)
    {
        super(x, y);
        setVulkleur(128, ((int) (Math.random() * 32.0)) + 255 - 31, 128);
    }

    /**
     * Teken het gras op het scherm
     */
    public void teken(Graphics g, int x, int y)
    {
        g.setColor(vulkleur);
        g.fillRect(x, y, Wereld.VAKGROOTTE, Wereld.VAKGROOTTE);
        g.setColor(lijnkleur);
        g.drawRect(x, y, Wereld.VAKGROOTTE, Wereld.VAKGROOTTE);
    }

}

