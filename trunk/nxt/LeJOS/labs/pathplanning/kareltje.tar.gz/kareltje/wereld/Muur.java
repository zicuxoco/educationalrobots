/*
 * Muur.java
 *
 * Created on 24 januari 2005, 17:08 by Bo Pennings
 */

package wereld;

import java.awt.*;

/**
 * Een muur op een vakje in de Wereld
 */
public class Muur extends WereldObject
{

    /**
     * Maak een muur op het opgegeven vakje
     * 
     * @param x
     *                de horizontale index van het vakje (vanaf links, telt vanaf 0)
     * @param y
     *                de verticale index van het vakje (vanaf boven, telt vanaf 0)
     */
    public Muur(int x, int y)
    {
        super(x, y);
      int randomkleurverschil = ((int) (Math.random() * 19.0));
        setVulkleur(150 - randomkleurverschil, 150 - randomkleurverschil, 150 - randomkleurverschil);
    }

    /**
     * Teken de muur op het scherm
     */
    public void teken(Graphics g, int x, int y)
    {
        g.setColor(vulkleur);
        g.fillRect(x, y, Wereld.VAKGROOTTE, Wereld.VAKGROOTTE);
        g.setColor(lijnkleur);
        g.drawRect(x, y, Wereld.VAKGROOTTE, Wereld.VAKGROOTTE);
    }

}

