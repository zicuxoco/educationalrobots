/*
 * Piepbal.java
 *
 * Created on 24 januari 2005, 17:08
 */

package wereld;

import java.awt.*;

/**
 * Een piepbal op een vakje in de Wereld
 */
public class Piepbal extends WereldObject
{

    /**
     * Maak een piepbal op het opgegeven vakje
     * 
     * @param x
     *                de horizontale index van het vakje (vanaf links, telt vanaf 0)
     * @param y
     *                de verticale index van het vakje (vanaf boven, telt vanaf 0)
     */
    public Piepbal(int x, int y)
    {
        super(x, y);
        setVulkleur(238, 193, 17);
        setLijnkleur(128, 128, 128);
    }

    /**
     * Teken de piepbal op het scherm
     */
    public void teken(Graphics g, int x, int y)
    {
        int z = 3;
        g.setColor(vulkleur);
        g.fillOval(x + z, y + z, Wereld.VAKGROOTTE - z - z, Wereld.VAKGROOTTE - z - z);
        g.setColor(lijnkleur);
        //g.drawOval(x+z,y+z,Wereld.VAKJE-z-z,Wereld.VAKJE-z-z);
    }

}

