/*
 * Robot.java
 *
 * Created on 24 januari 2005, 17:08
 */

package wereld;

import java.awt.*;
import javax.swing.*;

/**
 * Een robot die in een wereld van muren en piepballen rondloopt.
 */
public class Robot extends WereldObject
        implements Runnable
{
    public String naam = "";

    private int richting = 2;

    private Piepbal bal = null;

    /**
     * <code>programmaThread</code> runt het hoofdProgramma
     */
    private Thread programmaThread;
    
    /**
     * <code>stopper</code> houdt programma op bij het stappen
     */
    private boolean stopper;
    
    /**
     * <code>stopper</code> houdt programma op bij het stappen
     */
    private boolean errored;
    
    /**
     * Construeert een robot met de gegeven naam.
     * 
     * @param s
     *                naam van deze robot
     */
    public Robot(String s)
    {
        super(10, 10);
        naam = s;
        setVulkleur(200, 200, 255);
        setLijnkleur(128, 128, 128);
    }

    /**
     * Vertel het object in welke Wereld het staat
     * <br/>
     * Override van setWereld in WereldObject
     * 
     * @param w de wereld
     */
    public void setWereld(Wereld w)
    {
        super.setWereld(w);
        stapGedaan(naam + " is in de wereld geplaatst.", false);
    }

    /**
     * Vraag aan de robot wat zijn x-postie is.
     * 
     * @return de x-index van het vakje waar de robot staat. (boven is 0)
     */
    public int getX()
    {
        return pos_x;
        
    }

    /**
     * Vraag aan de robot wat zijn y-postie is.
     * 
     * @return de y-index van het vakje waar de robot staat. (links is 0)
     */
    public int getY()
    {
        return pos_y;
        
    }

    /**
     * Deze methode bevat het hoofdprogramma dat door de Robot wordt
     * uitgevoerd. 
     * In Robot zelf is deze methode leeg, er staat niets in en daarom doet
     * de Robot uit zichzelf niets. Maak een eigen versie van deze methode 
     * in je programma, deze wordt dan gedaan bij het runnen van je programma.
     * <p/>
     * NB: dit heet een <em>override</em>, we gaan er dieper op in bij course Game.
     */
    public void hoofdProgramma()
    {
        // empty!
    }

    public int riddersKlaar = 0;
    public int ridderNummer = 0;
    
    public void setRidderNummer(int nummer) {
        ridderNummer = nummer;
    }
    
    public int getRidderNummer() {
        return ridderNummer;
    }
       
    //maakt de functie ridderPlaatsGoud bekend voor compiler daarna word hij geoverride
    public void plaatsGoudKlompen()
    {
        //empty
    }
    
 // ------ managing the thread -------------------------------------------
    
    void setStopper(boolean s)
    {
        stopper = s;
    }
    
    /**
     * Pauzeert de verwerking van het hoofdprogramma voor slaaptijd milliseconden
     */
    private void pauze()
    {
        try
        {
            Thread.sleep(mijnWereld.getSlaaptijd());
        } catch (InterruptedException e)
        { // do nothing
        }
    }
    
    private void stapAfhandelen()
    {
        mijnWereld.repaint();
        while ( errored )
        {
            pauze();        // pause indefinitely after error
        }
        if (mijnWereld.getStepState() == Wereld.ANIMPAUSE)
        {
            pauze();
        } else if (mijnWereld.getStepState() == Wereld.ANIMSTEP)
        {
            pauze(); // minstens 1 pauze!
            while (stopper)
            {
                pauze();
            }
            stopper = true; // for next step
        }
    }
    
    /**
     * Handel een stap van een Robot af.
     * Afhankelijk van de gekozen run-opties is dit even pauzeren of wachten op de
     * volgende klik op de stapknop.
     * 
     * @param s log-mededeling die hoort bij de gedane actie
     */
    private void stapGedaan(String s, boolean logalways)
    {
        mijnWereld.addLineToLog(s, logalways  && !errored);
        stapAfhandelen();
    }
    
    private void foutOpgetreden(String s)
    {
        errored = true;
        setVulkleur(0, 0, 0);       // zwart!
        mijnWereld.foutOpgetreden(s);
        stapAfhandelen();
    }
        
    /** 
     * De run-methode zorgt ervoor dat het hoofdprogramma in een aparte Thread
     * uitgevoerd wordt.
     * NB: De run-methode wordt door de interface van de wereld aangeroepen 
     * wanneer je op de knop 'Start' klikt. De methode kun je niet gebruiken in je
     * eigen hoofdProgramma.
     * 
     * @see java.lang.Runnable#run()
     */
    public void run()
    {
        hoofdProgramma();
    }

    /**
     * start het hoofdprogramma in een aparte Thread
     */
    void startProgramma()
    {
        errored = false;
        stopper = true;
        programmaThread = new Thread(this);
        programmaThread.setDaemon(true);
        programmaThread.start();
    }

// ------ diverse Robot-acties -------------------------------------------
    
    public void slaap(int aantal) {
        for (int i = 0; i < aantal; i++){
            stapAfhandelen();
        }
    }

    /**
     * Neem een stap naar voren.
     */
    public void stap(int aantal)
    {
        for (int i = 0; i < aantal; i++){
        // N, W, Z, O
        if (richting == 0)
        {
            if (pos_y - 1 < 0)
            {
                foutOpgetreden(naam + " is van de wereld af gevallen.");
            } else if (mijnWereld.bezet(pos_x, pos_y - 1)) {
                    slaap(1);
                    stap(1);      
            } else
            {
                mijnWereld.verplaats(this, pos_x, pos_y - 1);
                stapGedaan(naam + " stapt.", false);
            }
        } else if (richting == 1)
        {
            if (pos_x + 1 >= mijnWereld.breedte)
            {
                foutOpgetreden(naam + " is van de wereld af gevallen.");
            } else if (mijnWereld.bezet(pos_x + 1, pos_y)) {
                
                slaap(1);
                stap(1);
                

                
            } else
            {
                mijnWereld.verplaats(this, pos_x + 1, pos_y);
                stapGedaan(naam + " stapt.", false);
           }
        } else if (richting == 2)
        {
            if (pos_y + 1 >= mijnWereld.hoogte)
            {
                foutOpgetreden(naam + " is van de wereld af gevallen.");
            } else if (mijnWereld.bezet(pos_x, pos_y + 1)) {
               
                if (mijnWereld.bezet(pos_x, pos_y + 1)) {
                    if (!mijnWereld.bezet(pos_x+1, pos_y)) {
                        draai("oost");
                    } else if (!mijnWereld.bezet(pos_x-1, pos_y)) {
                        draai("west");
                    } else if (!mijnWereld.bezet(pos_x, pos_y-1)) {
                        draai("noord");
                    }
                }
                slaap(1);
                stap(1);
                
            } else
            {
                mijnWereld.verplaats(this, pos_x, pos_y + 1);
                stapGedaan(naam + " stapt.", false);
           }
        } else
        {
            if (pos_x - 1 < 0)
            {
                foutOpgetreden(naam + " is van de wereld af gevallen.");
            } else if (mijnWereld.bezet(pos_x - 1, pos_y)) {
                
                if (mijnWereld.bezet(pos_x - 1, pos_y)) {
                    if (!mijnWereld.bezet(pos_x, pos_y+1)) {
                        draai("zuid");
                    } else if (!mijnWereld.bezet(pos_x, pos_y-1)) {
                        draai("noord");
                    } else if (!mijnWereld.bezet(pos_x+1, pos_y)) {
                        draai("oost");
                    }
                }
                slaap(1);
                stap(1);
                
            } else {
                mijnWereld.verplaats(this, pos_x - 1, pos_y);
                stapGedaan(naam + " stapt.", false);
            }
        }
        }
    }

    /**
     * Draai 90 graden naar links.
     */
    public void linksom()
    {
        richting = richting - 1;
        if (richting < 0)
            richting = 3;
        stapGedaan(naam + " gaat linksom.", false);
    }

    /**
     * Draai 90 graden naar rechts.
     */
    public void rechtsom()
    {
        richting = richting + 1;
        if (richting > 3)
            richting = 0;
        stapGedaan(naam + " gaat rechtsom.", false);
    }

    /**
     * Draai 180 graden om.
     */
    public void draaiom()
    {
        if (richting == 0)
            richting = 2;
        else if (richting == 1)
            richting = 3;
        else if (richting == 2)
            richting = 0;
        else if (richting == 3)
            richting = 1;
        stapGedaan(naam + " draait om.", false);
    }    
    
    /**
     * Draait naar opgegeven richting
     */    
    public void draai(String kant) {
        String soort;
        if (kant == "noord") {
            richting = 0;
            soort = "noorden";
        } else if (kant == "oost") {
            richting = 1;
            soort = "oosten";
        } else if (kant == "zuid") {
            richting = 2;
            soort = "zuiden";
        } else {
            richting = 3;
            soort = "westen";
        }
            stapGedaan(naam + " draait naar het " + soort + ".", false);
    }
  
    public void draaiSpeciaal(String kant) {
        String soort;
        if (kant == "noord") {
            richting = 0;
            soort = "noorden";
        } else if (kant == "oost") {
            richting = 1;
            soort = "oosten";
        } else if (kant == "zuid") {
            richting = 2;
            soort = "zuiden";
        } else {
            richting = 3;
            soort = "westen";
        }
    }
    
    /**
     * Staat deze robot voor een obstakel?
     * 
     * @return <CODE>true</CODE>, als er een obstakel voor deze robot staat, <br>
     *            <CODE>false</CODE>, anders.
     */
    public boolean voorObstakel()
    {
        boolean result;
        if (richting == 0)
        {
            result = ((pos_y - 1 < 0) || mijnWereld.bezet(pos_x, pos_y - 1));
        } else if (richting == 1)
        {
            result = ((pos_x + 1 >= mijnWereld.breedte) || mijnWereld.bezet(pos_x + 1, pos_y));
        } else if (richting == 2)
        {
            result = ((pos_y + 1 >= mijnWereld.hoogte) || mijnWereld.bezet(pos_x, pos_y + 1));
        } else
        {
            result = ((pos_x - 1 < 0) || mijnWereld.bezet(pos_x - 1, pos_y));
        }
        stapGedaan(naam+" voor obstakel geeft: "+result, false);
        return result;
    }

    /**
     * Staat de robot op een piepbal?
     * 
     * @return <CODE>true</CODE>, als deze robot op een piepbal staat, <BR>
     *            <CODE>false</CODE>, anders.
     */
    public boolean oppiepbal()
    {
        boolean result = mijnWereld.piepbal(pos_x, pos_y);
        stapGedaan(naam+" op piepbal geeft: "+result, false);
        return result;
    }

    /**
     * Pak de piepbal, mits deze robot op een piepbal staat en er geen heeft.
     */
    public void pakpiepbal()
    {
        if (!mijnWereld.piepbal(pos_x, pos_y) )
        {
            foutOpgetreden(naam + " probeert een bal te pakken, maar er is niks!");
        } else if (bal != null)
        {
            foutOpgetreden(naam + " probeert een bal te pakken, maar heeft er al een!");
        } else
        {
            bal = (Piepbal) mijnWereld.neem(pos_x, pos_y);
            stapGedaan(naam + " pakt een piepbal.", false);
        }
    }

    /**
     * Heeft deze robot een piepbal vast?
     * 
     * @return <CODE>true</CODE>, als de robot een piepbal vastheeft, <br />
     *            <CODE>false</CODE>, anders.
     */
    public boolean heeftpiepbal()
    {
        boolean result = (bal != null);
        stapGedaan(naam+" op piepbal geeft: "+result, false);
        return result;
    }

    /**
     * Leg een piepbal neer, mits de robot er een vast heeft en mits er niet al een piepbal op de grond ligt.
     */
    public void legpiepbal()
    {
        if (bal == null)
        {
            foutOpgetreden(naam + " probeert een bal te leggen, maar heeft er geen!");
        } else if (oppiepbal())
        {
            foutOpgetreden(naam + " probeert een bal te leggen, maar de plek is al bezet!");
        } else
        {
            mijnWereld.plaats(bal, pos_x, pos_y);
            bal = null;
            stapGedaan(naam + " legt een piepbal neer.", false);
        }
     }

    /**
     * Vertelt in welke richting de robot kijkt.
     * 
     * @return <CODE>0</CODE>, als de robot naar het noorden kijkt; <BR>
     *            <CODE>1</CODE>, als de robot naar het oosten kijkt; <BR>
     *            <CODE>2</CODE>, als de robot naar het zuiden kijkt; <BR>
     *            <CODE>3</CODE>, als de robot naar het westen kijkt.
     */
    public int kompas()
    {
        String r;
        if (richting == 0)
            r = "noord";
        else if ( richting == 1)
            r = "oost";
        else if ( richting == 2)
            r = "zuid";
        else
            r = "west";
        stapGedaan("het kompas van "+naam+" wijst naar: "+r, false);
        return richting;
    }

    /**
     * Spreek de gegeven tekst uit.
     * 
     * @param s
     *                de tekst die de robot zal uitspreken.
     */
    public void zeg(String s)
    {
        stapGedaan(naam + " zegt: '" + s + "'", true);
    }

    /**
     * Spreek het gegeven getal uit.
     * 
     * @param i
     *                het getal dat uitgesproken wordt.
     */
    public void zeg(int i)
    {
        zeg("" + i);
    }

    /**
     * Spreek de gegeven waarheidswaarde uit.
     * 
     * @param b
     *                de waarheidswaarde die uitgesproken wordt.
     */
    public void zeg(boolean b)
    {
        zeg("" + b);
    }

    /**
     * Vraag naar een ja/nee antwoord.
     * 
     * @param s
     *                de vraag die gesteld wordt.
     * @return <CODE>true</CODE>, als het antwoord bevestigend is, en <BR/><CODE>false</CODE>, anders.
     */
    public boolean vraag(String s)
    {
        boolean b;
        Object[] options =
        { "Ja", "Nee" };
        b = (JOptionPane.showOptionDialog(null, s, naam + " vraagt", JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE, null, options, options[0])) == 0;
        stapGedaan(naam + " vraagt: '" + s + "'", false);
        return b;
    }

        /**
     * Schreeuwt een string
     * 
     * @param s de string die geschreeuwt word
     * 
     * @return <CODE>true</CODE>, als het antwoord bevestigend is, en <BR/><CODE>false</CODE>, anders.
     */
    public boolean schreeuw(String s)
    {
        boolean b;
        Object[] options = { "Oke" };
        b = (JOptionPane.showOptionDialog(null, s, naam + " schreeuwt:", JOptionPane.OK_OPTION,
                JOptionPane.QUESTION_MESSAGE, null, options, options[0])) == 0;
        stapGedaan(naam + " schreeuwt: '" + s + "'", false);
        return b;
    }
    
    /**
     * Vraag naar een getal.
     * 
     * @param s
     *                De vraag die gesteld wordt.
     * @return het getal wat de gebruiker gegeven heeft, en <br/><CODE>0</CODE>, anders.
     */
    public int vraagGetal(String s)
    {
        int n;
        Object[] options =
        { "Ja", "Nee" };
        try
        {
            n = Integer.parseInt((String) JOptionPane.showInputDialog(null, s, naam + " vraagt een getal",
                    JOptionPane.PLAIN_MESSAGE, null, null, ""));
        } catch (Exception e)
        {
            n = 0;
        }
        stapGedaan(naam + " vraagt: '" + s + "'", false);
        return n;
    }

    /**
     * Vraag naar een tekstueel antwoord.
     * 
     * @param s
     *                de vraag die gesteld wordt.
     * 
     * @return het antwoord.
     */
    public String vraagTekst(String s)
    {
        String s0;
        Object[] options =
        { "Ja", "Nee" };
        s0 = ((String) JOptionPane.showInputDialog(null, s, naam + " vraagt een antwoord", JOptionPane.PLAIN_MESSAGE,
                null, //don't use a custom Icon
                null, //the titles of buttons
                ""));
        stapGedaan(naam + " vraagt: '" + s + "'", false);
        return s0;
    }

    /**
     * De methode dobbel laat de robot een dobbelsteen opgooien.
     * 
     * @return een getal van ��n tot en met zes.
     */
    public int dobbel()
    {
        int result = (int) (Math.random() * 6.0 + 1);
        stapGedaan(naam+" dobbelt en krijgt: "+result, false);
        return result;
    }

    /**
     * Teken deze robot.
     * 
     * @param g
     *                De graphics waar de robot getekend wordt.
     * @param x
     *                De x locatie op de graphics waar de robot getekend wordt.
     * @param y
     *                De y locatie op de graphics waar de robot getekend wordt.
     */
    public void teken(Graphics g, int x, int y)
    {
        int v = Wereld.VAKGROOTTE;
        int hv = v >> 1;

        if (richting == 0)
        {
            xx[0] = 0;
            xx[1] = hv;
            xx[2] = v;
            yy[0] = v;
            yy[1] = 0;
            yy[2] = v;
        } else if (richting == 1)
        {
            xx[0] = 0;
            xx[1] = v;
            xx[2] = 0;
            yy[0] = 0;
            yy[1] = hv;
            yy[2] = v;
        } else if (richting == 2)
        {
            xx[0] = 0;
            xx[1] = hv;
            xx[2] = v;
            yy[0] = 0;
            yy[1] = v;
            yy[2] = 0;
        } else
        {
            xx[0] = v;
            xx[1] = 0;
            xx[2] = v;
            yy[0] = 0;
            yy[1] = hv;
            yy[2] = v;
        }

        for (int i = 0; i < 3; i++)
        {
            xx[i] = xx[i] + x;
            yy[i] = yy[i] + y;
        }

        g.setColor(vulkleur);
        g.fillPolygon(xx, yy, 3);
        g.setColor(lijnkleur);
        g.drawPolygon(xx, yy, 3);
        if ( bal != null )
        {
            bal.teken(g, x, y);
        }
    }

    private int[] xx =
    { 0, 0, 0 };

    private int[] yy =
    { 0, 0, 0 };
}

