package algorithms.dijkstra;

import java.awt.Point;
import java.util.LinkedList;

import algorithms.SearchResult;

import pathfinding.gui.Map;

@Deprecated
public class DijkstraAlgorithmTester {

	public LinkedList<Point> neighboursOf(Point point, int[][] arrayMap) {
		LinkedList<Point> neighbours = new LinkedList<Point>();
		
		System.out.println((point.y + 1) + " " + arrayMap.length);
		for(int rowIndex = Math.max(0, point.y-1); rowIndex < Math.min(arrayMap.length, point.y + 1); rowIndex ++) {
			for(int colIndex = Math.max(0, point.x - 1); colIndex < Math.min(arrayMap[0].length, point.x + 1);  colIndex ++ ) {
				System.out.println("! " + rowIndex + " " + colIndex);
				if(rowIndex == point.y && colIndex == point.x) {
					
				} else {				
					Point neighbour = new Point(colIndex, rowIndex);
					neighbours.add(neighbour);
				} 
			}
		}
		
		System.out.println("Naapurit nodelle (" + point + "): " + neighbours);
		return neighbours;
	}
	
	public void doTest() {
		Map map = new Map(8, 8);
		Point start = new Point(1,1);
		Point end = new Point(3, 1);
		
		SearchResult res = new DijkstraStyleAlgorithm().findPath(start, end, map);
				
	}
	
	public static void main(String[] args) {
		new DijkstraAlgorithmTester().doTest();
//		System.out.println(new Point(0,0).equals(new Point(0,0)));
//		int[][] amap = new int[3][3];
//		for (int r=0; r < amap.length; r++) {
//		    for (int c=0; c < amap[r].length; c++) {
//		    	amap[r][c] = 0;
//		    }
//		}
//		DNode d = new DNode(1,1);
//		d.addNeighbours(amap);
//		System.out.println(d.getNeighbours().size());
	}
	
}
