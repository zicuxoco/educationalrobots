package pathfinding;

import javax.swing.ImageIcon;

public class IconStore {

	private ImageIcon startIcon;
	private ImageIcon goalIcon;
	private ImageIcon algorithmUnusedCandidate;
	private ImageIcon algorithmUsedCandidate;
	private ImageIcon algorithmSelectedPathIcon;
	
	private static IconStore SINGLETON;

	public static IconStore getInstance() {
		if(SINGLETON == null)
			SINGLETON = new IconStore();
		return SINGLETON;
	}
	
	private IconStore() {
		loadIcons();
	}
	
	public void loadIcons() {
		startIcon = createImageIcon("/images/start.png", "Start");
		goalIcon = createImageIcon("/images/goal.png", "Goal");
		algorithmUnusedCandidate = createImageIcon("/images/unused_candidate_cell.png", "Start");
		algorithmUsedCandidate = createImageIcon("/images/used_candidate_cell.png", "Start");
		algorithmSelectedPathIcon = createImageIcon("/images/path_cell.png", "Start");
	}

	private ImageIcon createImageIcon(String path, String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
	
	public ImageIcon getStartIcon() {
		return startIcon;
	}
	
	public ImageIcon getGoalIcon() {
		return goalIcon;
	}
	
	public ImageIcon getAlgorithmUsedCandidateIcon() {
		return algorithmUsedCandidate;
	}
	
	public ImageIcon getAlgorithmUnusedCandidateIcon() {
		return algorithmUnusedCandidate;
	}
	
	public ImageIcon getAlgorithmSelectedPathIcon() {
		return algorithmSelectedPathIcon;
	}
	
}
