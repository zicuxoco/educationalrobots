package algorithms.astar;

import java.awt.Point;

import algorithms.DescriptedPoint;

/**
 * Class for containing information for A*
 * 
 * @author teturun
 *
 */
public class Node implements Comparable<Node> {
	private DescriptedPoint location;
	private Node parent;
	
	private int gCost;
	private int hCost;
	
	public Node(DescriptedPoint location, Node parent) {
		this.location = location;
		this.parent = parent;
		this.gCost = Integer.MAX_VALUE;
		this.hCost = Integer.MAX_VALUE;
	}
	
	public int getGCost() {
		return gCost;
	}

	public int getHCost() {
		return hCost;
	}
	
	public void setGCost(int gCost) {
		this.gCost = gCost;
	}
	
	public void setHCost(int hCost) {
		this.hCost = hCost;
	}
	
	public int getFScore() {
		return this.gCost + this.hCost;
	}
	
	public DescriptedPoint getLocation() {
		return location;
	}

	public Node getParent() {
		return parent;
	}
	
	public void setParent(Node parent) {
		this.parent = parent;
	}
	
	public String toString() {
		return "Node: " + getLocation();
	}

	public boolean isDiagonalWith(Node node) {
		
		if (this.getLocation().x != node.getLocation().x &&
			this.getLocation().y != node.getLocation().y) {
				return true;
		}
		return false;
		
	}
	
	@Override
	public boolean equals(Object object) {
		if (object == this) 
			return true;
		
		if (! (object instanceof Node)) 
			return false;
		
		Node n = (Node) object;
		
		return this.getLocation().equals(n.getLocation());
	}
	
	@Override
	public int hashCode() {
		return this.location.hashCode();
	}

	@Override
	public int compareTo(Node object) {
		
		if (object == this) 
			return 0;

		if (this.getFScore() < object.getFScore()) 
			return -1;
		else if (this.getFScore() > object.getFScore()) 
			return 1;
		else 
			return 0;
	}
	
}
