package algorithms;

import java.util.Vector;


import algorithms.astar.AStarAlgorithm;
import algorithms.dijkstra.DijkstraStyleAlgorithm;

/**
 * Class holding path finding algorithms.
 *
 * @author teturun
 */
public class PathFindingAlgorithms {

	private Vector<PathFindingAlgorithm> algorithms;
	
	public PathFindingAlgorithms() {
		this.algorithms = new Vector<PathFindingAlgorithm>();
		addAlgorithm(new AStarAlgorithm());
		addAlgorithm(new DijkstraStyleAlgorithm());
	}

	public Vector<PathFindingAlgorithm> getAlgorithms() {
		return algorithms;
	}

	public void addAlgorithm(PathFindingAlgorithm algorithm) {
		
		if (! this.algorithms.contains(algorithm)) {
			this.algorithms.add(algorithm);
		}
		
	}
	
	public void removeAlgorithm(PathFindingAlgorithm algorithm) {
		this.algorithms.remove(algorithm);
	}
	
}
