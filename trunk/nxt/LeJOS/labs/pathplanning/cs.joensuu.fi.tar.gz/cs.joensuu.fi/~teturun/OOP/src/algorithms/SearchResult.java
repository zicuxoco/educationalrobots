package algorithms;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Class for holding path finding algorithm's search results.
 * 
 * @author teturun
 */
public class SearchResult {

	private Deque<DescriptedPoint> path; // the found path
	private Deque<DescriptedPoint> usedCandidates; // points that were estimated and chosen
	private Deque<DescriptedPoint> unUsedCandidates; // points that were estimated but not chosen
	
	private long timeInNanoseconds;
	
	public SearchResult() {
		this(new ArrayDeque<DescriptedPoint>(), 
			 new ArrayDeque<DescriptedPoint>(), 
			 new ArrayDeque<DescriptedPoint>(), 0);	
	}
	
	public SearchResult(Deque<DescriptedPoint> path, Deque<DescriptedPoint> usedCandidates, Deque<DescriptedPoint> unUsedCandidates, long timeInNanoseconds) {
		this.path = path;
		this.usedCandidates = usedCandidates;
		this.unUsedCandidates = unUsedCandidates;
		this.timeInNanoseconds = timeInNanoseconds;
	}

	public Deque<DescriptedPoint> getPath() {
		return path;
	}

	public void setPath(Deque<DescriptedPoint> path) {
		this.path = path;
	}

	public Deque<DescriptedPoint> getUsedCandidates() {
		return usedCandidates;
	}

	public void setUsedCandidates(Deque<DescriptedPoint> usedCandidates) {
		this.usedCandidates = usedCandidates;
	}

	public Deque<DescriptedPoint> getUnUsedCandidates() {
		return unUsedCandidates;
	}

	public void setUnUsedCandidates(Deque<DescriptedPoint> unUsedCandidates) {
		this.unUsedCandidates = unUsedCandidates;
	}

	public long getTimeInNanoseconds() {
		return timeInNanoseconds;
	}

	public void setTimeInNanoseconds(long timeInNanoseconds) {
		this.timeInNanoseconds = timeInNanoseconds;
	}
	
}
