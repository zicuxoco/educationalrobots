package pathfinding;

import algorithms.PathFindingAlgorithm;
import pathfinding.gui.Map;
import pathfinding.gui.MapCell;
import pathfinding.gui.MapCell.CellIkonType;

/**
 * Class for containing user settings and for setting
 * these settings to MapCells.
 * 
 * @author teturun
 *
 */
public class SettingsObject {

	private CellTerrainType cellTerrainType;
	private CellIkonType cellIconType;
	
	private PathFindingAlgorithm algorithm;
	
	private static SettingsObject SINGLETON;
	
	private SettingsObject() {
	}
	
	public static SettingsObject getInstance() {
		if (SINGLETON == null) {
			SINGLETON = new SettingsObject();
		}
		return SINGLETON;
	}
	
	public void setCellTerrainType(CellTerrainType cellTerrainType) {
		this.cellTerrainType = cellTerrainType;
		this.cellIconType = null;
	}
	
	public void setCellRole(CellIkonType cellIconType) {
		this.cellIconType = cellIconType;
		this.cellTerrainType = null;
	}
	
	public void doSettings(MapCell mapCell) {
		
		doCellTerrainTypeSettings(mapCell);
		doCellIconTypeSettings(mapCell);
		
	}
	
	private void doCellTerrainTypeSettings(MapCell mapCell) {
		if (cellTerrainType != null) {
			
			if (mapCell.getParent() != null && 
					mapCell.getParent() instanceof Map) {
				
				Map map = (Map) mapCell.getParent();
				mapCell.setCellTerrainType(this.cellTerrainType);
				map.setAsNotSpecialCell(mapCell);
			}
			
			
		}
	}
	
	private void doCellIconTypeSettings(MapCell mapCell) {

		if (cellIconType != null) {

			if (mapCell.getParent() != null && 
					mapCell.getParent() instanceof Map) {
				
				System.out.println("MAP ON PARENT");
				
				Map map = (Map) mapCell.getParent();

				switch (cellIconType) {
				
					case START:
						map.setStartCellTo(mapCell);
						this.cellTerrainType = CellTerrainType.FLOOR;
						mapCell.setCellTerrainType(this.cellTerrainType);
						break;
						
					case GOAL:
						map.setGoalCellTo(mapCell);
						this.cellTerrainType = CellTerrainType.FLOOR;
						mapCell.setCellTerrainType(this.cellTerrainType);
						break;
						
				}
			}

		}
	}

	public PathFindingAlgorithm getAlgorithm() {
		return algorithm;
	}

	public void setAlgorithm(PathFindingAlgorithm algorithm) {
		this.algorithm = algorithm;
	}
	
}
