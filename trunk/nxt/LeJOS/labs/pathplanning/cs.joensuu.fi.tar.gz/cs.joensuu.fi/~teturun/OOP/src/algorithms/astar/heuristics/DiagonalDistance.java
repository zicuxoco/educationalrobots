package algorithms.astar.heuristics;

import algorithms.astar.AStarCost;
import algorithms.astar.Node;

/**
 * DiagonalDistance heuristic implementation.
 * See A* tutorials for more information.
 * 
 * @author teturun
 *
 */
public class DiagonalDistance implements HCostHeuristic {

	public int calculateCost(Node start, Node goal) {
		
		int distanceX = Math.abs(goal.getLocation().x - start.getLocation().x);
		int distanceY = Math.abs(goal.getLocation().y - start.getLocation().y);
		
		int h_diagonal = Math.min(distanceX, distanceY);
		int h_straight = distanceX + distanceY;
		
		return (AStarCost.DIAGONAL_MOVE * h_diagonal) + 
		       (AStarCost.NORMAL_MOVE * (h_straight - 2*h_diagonal));

	}

	public String toString() {
		return "Diagonal distance";
	}
	
}
