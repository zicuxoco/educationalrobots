package pathfinding.gui.listeners;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import pathfinding.SettingsObject;
import pathfinding.gui.MapCell;

/**
 * MouseListener and MouseMotionListener class for user mouse input
 * (for MapCell mouse over effects and setting MapCells according to settings).
 * 
 * @author arttu viljakainen
 * @author teturun
 */
public class MouseInput implements MouseListener, MouseMotionListener {
	private static MouseInput SINGLETON;
	
	private boolean isPressed;
	
	public static MouseInput getInstance() {
		if(SINGLETON == null)
			SINGLETON = new MouseInput();
		return SINGLETON;
	}
	
	private MouseInput() {
		this.isPressed = false;
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// method left intentionally unimplemented
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		
		if (e.getSource() instanceof MapCell) {
			MapCell source = (MapCell) e.getSource();
			source.setBackground(source.mouseOverBgColor);
		}
		if (this.isPressed) {
			MapCell source = (MapCell) e.getSource();
			SettingsObject.getInstance().doSettings(source);
		}
	}

	@Override
	public void mouseExited(MouseEvent e) {
		
		if (e.getSource() instanceof MapCell) {
			MapCell source = (MapCell) e.getSource();
			source.setBackground(source.colorWhenNotMouseOver);
		}
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		if (e.getSource() instanceof MapCell) {
			MapCell source = (MapCell) e.getSource();
			SettingsObject.getInstance().doSettings(source);
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		this.isPressed = false;
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		this.isPressed = true;
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
	}	
	
}