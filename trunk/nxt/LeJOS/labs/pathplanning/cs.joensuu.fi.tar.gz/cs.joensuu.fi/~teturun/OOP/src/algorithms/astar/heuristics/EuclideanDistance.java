package algorithms.astar.heuristics;

import algorithms.astar.AStarCost;
import algorithms.astar.Node;

/**
 * EuclideanDistance heuristic implementation.
 * See A* tutorials for more information.
 * 
 * @author teturun
 *
 */
public class EuclideanDistance implements HCostHeuristic {

	public int calculateCost(Node start, Node goal) {

		int distanceX = Math.abs(goal.getLocation().x - start.getLocation().x);
		int distanceY = Math.abs(goal.getLocation().y - start.getLocation().y);
		double poweredSum = Math.pow(distanceX, 2) + Math.pow(distanceY, 2);
		
		return (int) (AStarCost.NORMAL_MOVE * Math.sqrt(poweredSum));
	}

	public String toString() {
		return "Euclidean distance";
	}
	
}
