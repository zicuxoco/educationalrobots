package pathfinding.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;

import pathfinding.gui.listeners.DialogUserActionListener;

/**
 * Dialog for adding maps.
 * 
 * @author teturun
 *
 */
public class AddMapDialog extends JDialog {
	
	private JSpinner rowSpinner;
	private JSpinner columnSpinner;
	
	private JCheckBox randomMapCheckBox;
	
	public AddMapDialog(SettingsPanel settingsPanel) {
		this.buildDialog(settingsPanel);
	}

	/**
	 * Builds the dialog. 
	 * 
	 * @param settingsPanel
	 */
	private void buildDialog(SettingsPanel settingsPanel) {
		
		this.setLayout(new BorderLayout());
		this.setPreferredSize(new Dimension(300,160));
		this.setMaximumSize(new Dimension(300,160));
		this.setMinimumSize(new Dimension(300,160));
		this.setTitle("Set map size");
		this.setModal(true);
		this.setLocationByPlatform(true);
		
		JLabel header = new JLabel("Set map size in rows and columns:");
		
		JPanel settings = new JPanel();
		settings.setLayout(new GridLayout(3, 2));
		
		settings.add(new JLabel("Rows:"));
		settings.add(new JLabel("Columns:"));
		
		SpinnerModel rowModel =
	        new SpinnerNumberModel(10, //initial value
	                               2, //min
	                               99, //max
	                               1); //step

		
		this.rowSpinner = new JSpinner();
		this.rowSpinner.setModel(rowModel);
		
		SpinnerModel colModel =
	        new SpinnerNumberModel(10, //initial value
	                               2, //min
	                               99, //max
	                               1); //step
		
		this.columnSpinner = new JSpinner();
		this.columnSpinner.setModel(colModel);
		
		this.randomMapCheckBox = new JCheckBox("Create random map");
		
		settings.add(this.rowSpinner);
		settings.add(this.columnSpinner);
		settings.add(this.randomMapCheckBox);
		
		JPanel buttonPanel = new JPanel();
		FlowLayout flowL = new FlowLayout();
		flowL.setAlignment(FlowLayout.TRAILING);
		buttonPanel.setLayout(flowL);
		buttonPanel.setPreferredSize(new Dimension(300,40));
		buttonPanel.setMaximumSize(new Dimension(300,40));
		buttonPanel.setMinimumSize(new Dimension(300,40));
		
		DialogUserActionListener listener = new DialogUserActionListener(settingsPanel);
		
		JButton okButton = new JButton("OK");
		okButton.addActionListener(listener);
		
		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(listener);
		
		buttonPanel.add(okButton);
		buttonPanel.add(cancelButton);
		
		this.add(header, BorderLayout.NORTH);
		this.add(settings, BorderLayout.CENTER);
		this.add(buttonPanel, BorderLayout.SOUTH);

	}
	
	/**
	 * Returns user's set map size.
	 * 
	 * @return map size
	 */
	public Dimension getMapSize() {
		int rows = (Integer)this.rowSpinner.getValue();
		int columns = (Integer)this.columnSpinner.getValue();
		return new Dimension(columns, rows);
	}
	
	/**
	 * Returns boolean according to user settings.
	 * 
	 * @return true, if random map will be generated, false if not
	 */
	public boolean createRandomMap() {
		return this.randomMapCheckBox.isSelected();
	}
	
}
