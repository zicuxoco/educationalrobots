package pathfinding;


public enum CellTerrainType {

	FLOOR(true, 0),
	WALL(false, 1);

	private final boolean isWalkable;
	private final int code;

	public boolean isWalkable() {
		return isWalkable;
	}
	
	public int getCode() {
		return code;
	}

	public int getCodeForCellType(CellTerrainType cellType) {
		return cellType.getCode();
	}
	
	private CellTerrainType(boolean isWalkable, int code) {
		this.isWalkable = isWalkable;
		this.code = code;
	}
}