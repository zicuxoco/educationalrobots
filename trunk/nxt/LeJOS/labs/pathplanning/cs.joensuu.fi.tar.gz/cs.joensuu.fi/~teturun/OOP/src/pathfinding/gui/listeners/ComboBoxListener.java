package pathfinding.gui.listeners;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JComboBox;

import pathfinding.gui.SettingsPanel;

/**
 * ItemListener class for JComboBox.
 * 
 * @author teturun
 */
public class ComboBoxListener implements ItemListener {

		private SettingsPanel master;
		
		public ComboBoxListener(SettingsPanel master) {
			this.master = master;
		}
		
		@Override
		public void itemStateChanged(ItemEvent event) {

			if (event.getStateChange() == ItemEvent.SELECTED) {
				
				if (event.getSource() instanceof JComboBox) {
					JComboBox source = (JComboBox)event.getSource();
					this.master.comboBoxItemChangePerformed(source);
				}
				
		    }
			
		}

	}