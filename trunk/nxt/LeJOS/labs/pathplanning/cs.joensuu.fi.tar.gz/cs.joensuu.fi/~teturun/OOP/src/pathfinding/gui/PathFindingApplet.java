package pathfinding.gui;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.JApplet;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextPane;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;

/**
 * Base for the application.
 * 
 * @author arttu viljakainen
 * @author teturun
 *
 */
public class PathFindingApplet extends JApplet {

	private final int APPLET_WIDTH = 640;
	private final int APPLET_HEIGHT = 480;
	
	private JTabbedPane tabPane;
		
	public void init() {
		
		try {
	        javax.swing.SwingUtilities.invokeAndWait(new Runnable() {
	            public void run() {
	            	setLookAndFeel("Nimbus");
	                createGUI();
	            }
	        });
	    } catch (Exception e) {
	        System.err.println("createGUI didn't successfully complete:");
	        e.printStackTrace();
	    }

	}
	
	private void createGUI() {
		
		JPanel startPanel = new JPanel();
		startPanel.setLayout(new BorderLayout());
		JTextPane textPane = new JTextPane();
		textPane.setContentType("text/html");
		textPane.setEditable(false);
		textPane.setText("<html>" +
				"<font size=+2><b>" +
				"Tool for Path Finding Algorithm Testing" +
				"</b></font><br>" +
				"by Arttu Viljakainen and Teemu Turunen (2009)<br>" +
				"<p>" +
				"Start by clicking \"Add new map\" button on the settings panel." +
				"</p>" +
				"<p>" +
				"You can modify map cells (add floors and walls) by clicking corresponding" +
				" buttons on the settings panel and then by clicking the map cell you want to modify."  +
				"</p>" +
				"<p>" +
				"You can (and must) also set starting and goal points " +
				"in the way described above in order to make a search." +
				"</p>" +
				"</html>");

		startPanel.add(textPane, BorderLayout.CENTER);

		tabPane = new JTabbedPane();
		tabPane.add(startPanel, "Welcome");
				
		SettingsPanel sidePanel = new SettingsPanel(this);
		
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		mainPanel.setBackground(Color.WHITE);
		mainPanel.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.BLACK));
		
		mainPanel.add(tabPane, BorderLayout.CENTER);
		mainPanel.add(sidePanel, BorderLayout.EAST);
		
		this.setLayout(new BorderLayout());
		this.add(mainPanel, BorderLayout.CENTER);
		this.setSize(APPLET_WIDTH, APPLET_HEIGHT);
		
	}
	
	public void setLookAndFeel(String name) {
		System.out.println("setLookAndFeel: " + name);

		try {

			for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {

				if (name.equals(info.getName())) {
					UIManager.setLookAndFeel(info.getClassName());
					break;
				}

			}

		} catch (Exception e) {
			// handle exception
		}

	}
	
	public JTabbedPane getTabbedPane() {
		return this.tabPane;
	}
	
	
		
	public void start() {
    }
	
	public void stop() {
    }

    public void destroy() {
    }

	
}
