package algorithms.astar.heuristics;

import algorithms.astar.AStarCost;
import algorithms.astar.Node;

/**
 * ManhattanDistance heuristic implementation.
 * See A* tutorials for more information.
 * 
 * @author teturun
 *
 */
public class ManhattanDistance implements HCostHeuristic {

	public int calculateCost(Node start, Node goal) {
		int distanceX = Math.abs(start.getLocation().x - goal.getLocation().x);
		int distanceY = Math.abs(start.getLocation().y - goal.getLocation().y);

		return AStarCost.NORMAL_MOVE * (distanceX + distanceY);
	}
	
	public String toString() {
		return "Manhattan distance";
	}
	
}
