package pathfinding.gui.listeners;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JToggleButton;

import pathfinding.gui.SettingsPanel;

/**
 * ItemListener class for JToggleButtons.
 *
 * @author teturun
 */
public class ToggleButtonListener implements ItemListener {

		private SettingsPanel master;
		
		public ToggleButtonListener(SettingsPanel master) {
			this.master = master;
		}
		
		@Override
		public void itemStateChanged(ItemEvent event) {
			
			if (event.getStateChange() == ItemEvent.SELECTED) {
				
				if (event.getSource() instanceof JToggleButton) {
					JToggleButton selected = (JToggleButton)event.getSource();
					this.master.toggleButtonClickPerformed(selected);
				}
				
			}
			
		}
		
	}