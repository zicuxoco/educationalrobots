package pathfinding.gui.listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import pathfinding.gui.SettingsPanel;

/**
 * ActionListener for JDialog (for adding new map) buttons.
 * 
 * @author teturun
 */
public class DialogUserActionListener implements ActionListener {

	private SettingsPanel master;
	
	public DialogUserActionListener(SettingsPanel master) {
		this.master = master;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getActionCommand().compareTo("OK") == 0) {
			this.master.dialogOkPerformed();
		}
		else if (e.getActionCommand().compareTo("Cancel") == 0) {
			this.master.dialogCancelPerformed();
		}
		
	}
	
}
