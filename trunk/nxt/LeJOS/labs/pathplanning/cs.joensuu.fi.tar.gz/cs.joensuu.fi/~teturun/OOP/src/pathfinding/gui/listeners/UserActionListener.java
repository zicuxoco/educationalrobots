package pathfinding.gui.listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import pathfinding.gui.SettingsPanel;

/**
 * ActionListener for JButtons in the settings panel.
 *
 * @author teturun
 */
public class UserActionListener implements ActionListener {

	private SettingsPanel settingsPanel;
	
	public UserActionListener(SettingsPanel settingsPanel) {
		this.settingsPanel = settingsPanel;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		
		if (event.getSource() instanceof JButton) {
			this.settingsPanel.buttonClickPerformed((JButton)event.getSource());
		}
		
	}

}
