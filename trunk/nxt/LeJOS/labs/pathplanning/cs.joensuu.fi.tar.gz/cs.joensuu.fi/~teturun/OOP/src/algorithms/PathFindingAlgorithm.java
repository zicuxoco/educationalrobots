package algorithms;

import java.awt.Point;
import java.util.Deque;

import pathfinding.gui.Map;

/**
 * Interface for path finding algorithms.
 * 
 * @author arttu viljakainen
 * @author teturun
 */
public interface PathFindingAlgorithm {
	
	/**
	 * Method for finding path from given start point to goal point
	 * using Map object. Found path (if any) depends on path finding algorithm
	 * class that overrides this method.
	 * 
	 * @param start the point where the search begins
	 * @param goal the goal point
	 * @param map Map object the path finding algorithm uses
	 * @return SearchResult object containing path and possibly other relevant information
	 * about the search and <code>null</code> if no path is found.
	 */
	public SearchResult findPath(Point start, Point goal, Map map);
	public String toString();
	
}
