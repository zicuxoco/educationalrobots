package algorithms;

import java.awt.Point;

/**
 * Class that extends Point by adding String field
 * pointDescription for use.
 * 
 * @author teturun
 */
public class DescriptedPoint extends Point {

	private String pointDescription;
	
	public DescriptedPoint() {
		super();
	}
	
	public DescriptedPoint(int x, int y) {
		super(x, y);
	}
	
	public void setDescription(String text) {
		this.pointDescription = text;
	}
	
	public String getDescription() {
		
		if (this.pointDescription == null)
			return "";
		else
			return this.pointDescription;
		
	}
}
