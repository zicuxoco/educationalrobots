package algorithms.astar.heuristics;

import algorithms.astar.Node;

/**
 * Interface for different H cost heuristics.
 * For more about A* heuristics, see A* tutorials for more information.
 * 
 * @author teturun
 *
 */
public interface HCostHeuristic {

	/**
	 * Calculates H cost according to used heuristic.
	 * For more about A* heuristics, see A* tutorials for more information.
	 * 
	 * @param start Node to which H cost is calculated
	 * @param goal Node that algorithm tries to reach
	 * @return H cost
	 */
	public abstract int calculateCost(Node start, Node goal);
	public abstract String toString();
}
