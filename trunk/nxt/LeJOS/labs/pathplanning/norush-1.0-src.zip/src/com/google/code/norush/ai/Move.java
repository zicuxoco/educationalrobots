package com.google.code.norush.ai;

/**
 * Empty interface for a transformation from one state to another.
 * 
 * @author DL, GT
 */
public interface Move {}
